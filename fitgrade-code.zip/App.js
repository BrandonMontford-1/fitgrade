import React, { useEffect, useRef, useState } from 'react';
import { ActivityIndicator, PanResponder, StyleSheet, View } from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import { Provider as PaperProvider } from 'react-native-paper';
import { onAuthChange, getTrainerProfile } from './src/services/firebaseService';
import LoginScreen from './src/screens/LoginScreen';
import SignupScreen from './src/screens/SignupScreen';
import TrainerHomeScreen from './src/screens/TrainerHomeScreen';
import ClientDetailScreen from './src/screens/ClientDetailScreen';
import OnboardingScreen from './src/screens/OnboardingScreen';
import OfflineBanner from './src/components/OfflineBanner';
import ErrorBoundary from './src/components/ErrorBoundary';
import { PALETTE } from './src/ui/theme';

export default function App() {
  const [authState, setAuthState] = useState('loading');
  const [trainer, setTrainer] = useState(null);
  const [selectedClient, setSelectedClient] = useState(null);
  const [screen, setScreen] = useState('login');
  const [needsOnboarding, setNeedsOnboarding] = useState(false);

  // Swipe back gesture for client detail
  const swipeBack = useRef(
    PanResponder.create({
      onMoveShouldSetPanResponder: (_, g) => g.dx > 20 && Math.abs(g.dy) < 40,
      onPanResponderRelease: (_, g) => {
        if (g.dx > 80) setSelectedClient(null);
      },
    })
  ).current;

  useEffect(() => {
    const unsub = onAuthChange(async (user) => {
      if (user) {
        const profile = await getTrainerProfile(user.uid);
        const data = profile.success ? profile.data : {};
        setTrainer({
          uid: user.uid,
          email: user.email,
          name: data.name || user.email,
          specialty: data.specialty || '',
          createdAt: data.createdAt || null,
        });
        setNeedsOnboarding(!data.onboarded);
        setAuthState('home');
      } else {
        setTrainer(null);
        setSelectedClient(null);
        setNeedsOnboarding(false);
        setAuthState('auth');
      }
    });
    return unsub;
  }, []);

  // Loading spinner while Firebase checks auth
  if (authState === 'loading') {
    return (
      <SafeAreaProvider>
        <View style={styles.loading}>
          <ActivityIndicator size="large" color={PALETTE.accent} />
        </View>
      </SafeAreaProvider>
    );
  }

  return (
    <ErrorBoundary>
      <SafeAreaProvider>
        <PaperProvider>
          <SafeAreaView style={styles.root} edges={['top', 'left', 'right']}>

          {/* Offline banner */}
          <OfflineBanner />

          {/* Auth */}
          {authState === 'auth' && screen === 'login' && (
            <LoginScreen onNavigateSignup={() => setScreen('signup')} />
          )}
          {authState === 'auth' && screen === 'signup' && (
            <SignupScreen onNavigateLogin={() => setScreen('login')} />
          )}

          {/* Onboarding — first launch */}
          {authState === 'home' && trainer && needsOnboarding && (
            <OnboardingScreen
              trainer={trainer}
              onComplete={(updates) => {
                setTrainer((prev) => ({ ...prev, ...updates }));
                setNeedsOnboarding(false);
              }}
            />
          )}

          {/* Roster */}
          {authState === 'home' && trainer && !needsOnboarding && !selectedClient && (
            <TrainerHomeScreen
              trainer={trainer}
              onSelectClient={setSelectedClient}
            />
          )}

          {/* Client detail with swipe back */}
          {authState === 'home' && trainer && !needsOnboarding && selectedClient && (
            <View style={{ flex: 1 }} {...swipeBack.panHandlers}>
              <ClientDetailScreen
                client={selectedClient}
                trainerId={trainer.uid}
                onBack={() => setSelectedClient(null)}
              />
            </View>
          )}

        </SafeAreaView>
      </PaperProvider>
    </SafeAreaProvider>
    </ErrorBoundary>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: PALETTE.background },
  loading: {
    flex: 1,
    backgroundColor: PALETTE.background,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
