import React from 'react';
import {
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { PALETTE } from '../ui/theme';

const SECTIONS = [
  {
    title: 'Acceptance of terms',
    body: 'By using FitGrade, you agree to these Terms of Service. If you do not agree, please do not use the app. These terms apply to all users including trainers, coaches, and athletes.',
  },
  {
    title: 'Use of the service',
    body: 'FitGrade is a tool for personal trainers to track client health grades and session data. You are responsible for the accuracy of data you enter. FitGrade is not a medical device and does not provide medical advice.',
  },
  {
    title: 'Medical disclaimer',
    body: 'FitGrade is not a substitute for professional medical advice, diagnosis, or treatment. Health grades and recommendations in the app are informational only. Always consult a qualified healthcare professional for medical concerns.',
  },
  {
    title: 'Account responsibilities',
    body: 'You are responsible for maintaining the confidentiality of your account credentials. You must not share account access with unauthorized parties. You are responsible for all activity that occurs under your account.',
  },
  {
    title: 'Client data',
    body: 'As a trainer, you are responsible for obtaining appropriate consent from clients before entering their health data into FitGrade. You must comply with applicable privacy laws in your jurisdiction regarding the handling of client health information.',
  },
  {
    title: 'Prohibited use',
    body: 'You may not use FitGrade for any unlawful purpose, to harm others, to impersonate another person, to submit false information, or to interfere with the service or its infrastructure.',
  },
  {
    title: 'Limitation of liability',
    body: 'FitGrade is provided "as is" without warranties of any kind. We are not liable for any damages arising from your use of the service, including decisions made based on data in the app.',
  },
  {
    title: 'Termination',
    body: 'We reserve the right to suspend or terminate accounts that violate these terms. You may delete your account at any time from the Profile & Settings screen.',
  },
  {
    title: 'Changes to terms',
    body: 'We may update these terms at any time. Continued use of FitGrade after changes constitutes acceptance of the updated terms.',
  },
  {
    title: 'Contact',
    body: 'For questions about these terms, contact us at legal@fitgrade.app',
  },
];

export default function TermsOfServiceScreen({ onBack }) {
  return (
    <View style={styles.root}>
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack} style={styles.backBtn}>
          <MaterialCommunityIcons name="arrow-left" size={22} color={PALETTE.silver} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Terms of Service</Text>
        <View style={{ width: 30 }} />
      </View>

      <ScrollView style={styles.scroll} contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <Text style={styles.updated}>Last updated: May 2026</Text>
        <Text style={styles.intro}>
          These Terms of Service govern your use of FitGrade. Please read them carefully before using the app.
        </Text>

        {SECTIONS.map((section) => (
          <View key={section.title} style={styles.section}>
            <Text style={styles.sectionTitle}>{section.title}</Text>
            <Text style={styles.sectionBody}>{section.body}</Text>
          </View>
        ))}

        <Text style={styles.footer}>FitGrade · Version 1.0.0</Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: PALETTE.background },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 14,
    borderBottomWidth: 1, borderBottomColor: PALETTE.divider,
  },
  backBtn: { padding: 4 },
  headerTitle: { color: PALETTE.text, fontSize: 18, fontWeight: '800' },
  scroll: { flex: 1 },
  scrollContent: { padding: 20, paddingBottom: 48 },
  updated: { color: PALETTE.muted, fontSize: 12, marginBottom: 14 },
  intro: {
    color: PALETTE.text, fontSize: 14, lineHeight: 22,
    backgroundColor: PALETTE.panel, borderRadius: 14,
    borderWidth: 1, borderColor: PALETTE.border,
    padding: 14, marginBottom: 20,
  },
  section: { marginBottom: 20 },
  sectionTitle: {
    color: PALETTE.accent, fontSize: 14, fontWeight: '800',
    marginBottom: 8, textTransform: 'capitalize',
  },
  sectionBody: { color: PALETTE.text, fontSize: 14, lineHeight: 22 },
  footer: {
    color: PALETTE.muted, fontSize: 12,
    textAlign: 'center', marginTop: 20,
  },
});
