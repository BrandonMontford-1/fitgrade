import React, { useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { saveSession, setAthleteCanEdit } from '../services/firebaseService';
import Toast from '../components/Toast';
import SessionTemplateModal from '../components/SessionTemplateModal';
import { getRecommendations, getRecommendationLevel } from '../data/recommendations';
import {
  BODY_PARTS,
  PALETTE,
  PART_META,
  getNumericGrade,
  getSeverityMeta,
  gradeColor,
} from '../ui/theme';

const INJURY_SEVERITY = ['Mild', 'Moderate', 'Severe'];

// ─── Single body part row ─────────────────────────────────────────────────────
function GradeRow({ part, grade, target, injured, injuryNote, injurySeverity,
  onGradeChange, onTargetChange, onInjuryToggle, onInjuryNoteChange,
  onSeverityChange, canEdit }) {

  const color = gradeColor(grade);
  const severity = getSeverityMeta(grade);
  const [expanded, setExpanded] = useState(false);
  const [showRecs, setShowRecs] = useState(false);
  const recs = getRecommendations(part, grade);
  const recLevel = getRecommendationLevel(grade);

  return (
    <View style={[styles.partCard, injured && { borderColor: PALETTE.danger + '55' }]}>
      {/* Header row */}
      <TouchableOpacity style={styles.partHeader} onPress={() => setExpanded(!expanded)} activeOpacity={0.8}>
        <View style={[styles.partIconWrap, { backgroundColor: severity.soft }]}>
          <MaterialCommunityIcons name={PART_META[part].icon} size={18} color={color} />
        </View>
        <View style={styles.partInfo}>
          <Text style={styles.partName}>{part}</Text>
          <Text style={styles.partHint}>{PART_META[part].shortHint}</Text>
        </View>
        <View style={styles.partRight}>
          {canEdit && (
            <TouchableOpacity
              onPress={() => onInjuryToggle(part, !injured)}
              style={[styles.injuryBtn, injured && { backgroundColor: PALETTE.danger, borderColor: PALETTE.danger }]}
            >
              <MaterialCommunityIcons
                name="alert-circle-outline"
                size={14}
                color={injured ? '#fff' : PALETTE.muted}
              />
              <Text style={[styles.injuryBtnText, injured && { color: '#fff' }]}>
                {injured ? 'Injured' : 'Flag'}
              </Text>
            </TouchableOpacity>
          )}
          {injured && !canEdit && (
            <MaterialCommunityIcons name="alert-circle" size={16} color={PALETTE.danger} />
          )}
          <Text style={[styles.partGradeText, { color }]}>{grade}%</Text>
          <MaterialCommunityIcons
            name={expanded ? 'chevron-up' : 'chevron-down'}
            size={18} color={PALETTE.muted}
          />
        </View>
      </TouchableOpacity>

      {/* Progress bar with target marker */}
      <View style={styles.barTrack}>
        <View style={[styles.barFill, { width: `${grade}%`, backgroundColor: color }]} />
        {target > 0 && (
          <View style={[styles.targetMarker, { left: `${target}%` }]} />
        )}
      </View>

      {/* Expanded section */}
      {expanded && (
        <View style={styles.expanded}>
          {canEdit ? (
            <>
              {/* Grade input */}
              <View style={styles.inputRow}>
                <Text style={styles.inputLabel}>Current grade</Text>
                <View style={styles.numInputWrap}>
                  <TextInput
                    style={[styles.numInput, { color }]}
                    value={String(grade)}
                    onChangeText={(v) => onGradeChange(part, v)}
                    keyboardType="numeric"
                    maxLength={3}
                    selectTextOnFocus
                  />
                  <Text style={[styles.pct, { color }]}>%</Text>
                </View>
              </View>

              {/* Target input */}
              <View style={styles.inputRow}>
                <Text style={styles.inputLabel}>Target grade</Text>
                <View style={styles.numInputWrap}>
                  <TextInput
                    style={[styles.numInput, { color: PALETTE.accent }]}
                    value={target > 0 ? String(target) : ''}
                    onChangeText={(v) => onTargetChange(part, v)}
                    keyboardType="numeric"
                    maxLength={3}
                    placeholder="—"
                    placeholderTextColor={PALETTE.muted}
                    selectTextOnFocus
                  />
                  <Text style={[styles.pct, { color: PALETTE.accent }]}>%</Text>
                </View>
              </View>
            </>
          ) : (
            target > 0 && (
              <View style={styles.readOnlyRow}>
                <MaterialCommunityIcons name="flag-outline" size={14} color={PALETTE.accent} />
                <Text style={styles.readOnlyText}>Target: {target}%</Text>
              </View>
            )
          )}

          {/* Injury details */}
          {injured && (
            <View style={styles.injuryBox}>
              <Text style={styles.injuryBoxLabel}>INJURY</Text>

              {canEdit ? (
                <>
                  <View style={styles.severityRow}>
                    {INJURY_SEVERITY.map((s) => (
                      <TouchableOpacity
                        key={s}
                        onPress={() => onSeverityChange(part, s)}
                        style={[styles.sevBtn, injurySeverity === s && styles.sevBtnActive]}
                      >
                        <Text style={[styles.sevBtnText, injurySeverity === s && styles.sevBtnTextActive]}>
                          {s}
                        </Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                  <TextInput
                    style={styles.injuryNoteInput}
                    placeholder="Describe injury, symptoms, restrictions..."
                    placeholderTextColor={PALETTE.muted}
                    value={injuryNote}
                    onChangeText={(v) => onInjuryNoteChange(part, v)}
                    multiline
                    numberOfLines={3}
                  />
                </>
              ) : (
                <>
                  {injurySeverity && (
                    <View style={styles.readOnlyRow}>
                      <MaterialCommunityIcons name="medical-bag" size={14} color={PALETTE.danger} />
                      <Text style={[styles.readOnlyText, { color: PALETTE.danger }]}>
                        {injurySeverity} severity
                      </Text>
                    </View>
                  )}
                  {injuryNote ? <Text style={styles.injuryNoteReadOnly}>{injuryNote}</Text> : null}
                </>
              )}
            </View>
          )}

          {/* Recommendations */}
          <TouchableOpacity
            style={[styles.recToggle, { borderColor: recLevel.color + '44' }]}
            onPress={() => setShowRecs(!showRecs)}
            activeOpacity={0.8}
          >
            <View style={styles.recToggleLeft}>
              <MaterialCommunityIcons name="dumbbell" size={13} color={recLevel.color} />
              <Text style={[styles.recToggleLabel, { color: recLevel.color }]}>
                {recLevel.label} Recommendations
              </Text>
            </View>
            <MaterialCommunityIcons
              name={showRecs ? 'chevron-up' : 'chevron-down'}
              size={15} color={PALETTE.muted}
            />
          </TouchableOpacity>

          {showRecs && (
            <View style={styles.recList}>
              {recs.map((rec, i) => (
                <View key={i} style={styles.recItem}>
                  <View style={[styles.recDot, { backgroundColor: recLevel.color }]} />
                  <Text style={styles.recText}>{rec}</Text>
                </View>
              ))}
            </View>
          )}
        </View>
      )}
    </View>
  );
}

// ─── Main ─────────────────────────────────────────────────────────────────────
export default function LogSessionScreen({ client, trainerId, onBack, onSaved, role = 'trainer' }) {
  const canEdit = role === 'trainer' || (role === 'athlete' && client?.athleteCanEdit);

  const [grades, setGrades] = useState(() =>
    Object.fromEntries(BODY_PARTS.map((p) => [p, getNumericGrade(client?.[p], 100)]))
  );
  const [targets, setTargets] = useState(() =>
    Object.fromEntries(BODY_PARTS.map((p) => [p, client?.targets?.[p] ?? 0]))
  );
  const [injuries, setInjuries] = useState(() =>
    Object.fromEntries(BODY_PARTS.map((p) => [p, client?.injuries?.[p] ?? false]))
  );
  const [injuryNotes, setInjuryNotes] = useState(() =>
    Object.fromEntries(BODY_PARTS.map((p) => [p, client?.injuryNotes?.[p] ?? '']))
  );
  const [injurySeverities, setInjurySeverities] = useState(() =>
    Object.fromEntries(BODY_PARTS.map((p) => [p, client?.injurySeverities?.[p] ?? 'Mild']))
  );
  const [sessionNote, setSessionNote] = useState('');
  const [athleteCanEdit, setAthleteCanEditLocal] = useState(client?.athleteCanEdit ?? false);
  const [saving, setSaving] = useState(false);
  const [toastVisible, setToastVisible] = useState(false);
  const [toastMsg, setToastMsg] = useState('');
  const [showTemplates, setShowTemplates] = useState(false);

  const handleGradeChange = (part, val) => {
    const parsed = Math.max(0, Math.min(100, parseInt(val) || 0));
    setGrades((prev) => ({ ...prev, [part]: parsed }));
  };

  const handleTargetChange = (part, val) => {
    const parsed = Math.max(0, Math.min(100, parseInt(val) || 0));
    setTargets((prev) => ({ ...prev, [part]: parsed }));
  };

  const handleSave = async () => {
    if (!trainerId || !client?.id) {
      Alert.alert('Error', 'Missing trainer or client info.');
      return;
    }

    setSaving(true);

    // Save session to Firebase
    const result = await saveSession(trainerId, client.id, {
      grades,
      targets,
      injuries,
      injuryNotes,
      injurySeverities,
      sessionNote,
    });

    // Save athlete edit permission if changed
    if (role === 'trainer' && athleteCanEdit !== client?.athleteCanEdit) {
      await setAthleteCanEdit(trainerId, client.id, athleteCanEdit);
    }

    setSaving(false);

    if (!result.success) {
      Alert.alert('Save Failed', result.message || 'Could not save session.');
      return;
    }

    // Return updated client data to parent
    onSaved?.({
      ...grades,
      targets,
      injuries,
      injuryNotes,
      injurySeverities,
      athleteCanEdit,
    });

    setToastMsg('Session saved ✓');
    setToastVisible(true);
    setTimeout(() => {
      setToastVisible(false);
      onBack();
    }, 1800);
  };

  return (
    <View style={styles.root}>
      <Toast message={toastMsg} visible={toastVisible} type="success" />
      <SessionTemplateModal
        visible={showTemplates}
        onClose={() => setShowTemplates(false)}
        currentGrades={grades}
        currentTargets={targets}
        onLoad={(t) => {
          setGrades(t.grades);
          setTargets(t.targets);
        }}
      />
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack} style={styles.backBtn}>
          <MaterialCommunityIcons name="arrow-left" size={22} color={PALETTE.silver} />
        </TouchableOpacity>
        <View style={styles.headerCenter}>
          <Text style={styles.headerTitle}>
            {role === 'trainer' ? 'Log Session' : role === 'athlete' ? 'My Status' : 'View Only'}
          </Text>
          <Text style={styles.headerSub}>{client?.name}</Text>
        </View>
        {canEdit && (
          <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center' }}>
            <TouchableOpacity onPress={() => setShowTemplates(true)} style={styles.templateBtn}>
              <MaterialCommunityIcons name="clipboard-list-outline" size={20} color={PALETTE.accent} />
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.saveBtn, saving && { opacity: 0.6 }]}
              onPress={handleSave}
              disabled={saving}
            >
              {saving
                ? <ActivityIndicator size="small" color="#fff" />
                : <Text style={styles.saveBtnText}>Save</Text>
              }
            </TouchableOpacity>
          </View>
        )}
      </View>

      {/* Role banner */}
      <View style={[styles.roleBanner, {
        backgroundColor: role === 'trainer' ? PALETTE.accentSoft : role === 'athlete' ? '#162316' : PALETTE.panelAlt,
        borderColor: role === 'trainer' ? PALETTE.accent : role === 'athlete' ? PALETTE.success : PALETTE.muted,
      }]}>
        <MaterialCommunityIcons
          name={role === 'trainer' ? 'clipboard-edit-outline' : role === 'athlete' ? 'account-outline' : 'eye-outline'}
          size={14}
          color={role === 'trainer' ? PALETTE.accent : role === 'athlete' ? PALETTE.success : PALETTE.muted}
        />
        <Text style={[styles.roleBannerText, {
          color: role === 'trainer' ? PALETTE.accent : role === 'athlete' ? PALETTE.success : PALETTE.muted,
        }]}>
          {role === 'trainer' ? 'Trainer — full edit + saves to Firebase' :
           role === 'athlete' ? canEdit ? 'Athlete — edit enabled by trainer' : 'Athlete — read only' :
           'Coach — read only'}
        </Text>
      </View>

      <ScrollView style={styles.scroll} contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>

        {BODY_PARTS.map((part) => (
          <GradeRow
            key={part}
            part={part}
            grade={grades[part]}
            target={targets[part]}
            injured={injuries[part]}
            injuryNote={injuryNotes[part]}
            injurySeverity={injurySeverities[part]}
            canEdit={canEdit}
            onGradeChange={handleGradeChange}
            onTargetChange={handleTargetChange}
            onInjuryToggle={(p, v) => setInjuries((prev) => ({ ...prev, [p]: v }))}
            onInjuryNoteChange={(p, v) => setInjuryNotes((prev) => ({ ...prev, [p]: v }))}
            onSeverityChange={(p, v) => setInjurySeverities((prev) => ({ ...prev, [p]: v }))}
          />
        ))}

        {/* Session note */}
        {role === 'trainer' && (
          <View style={styles.noteSection}>
            <Text style={styles.sectionLabel}>SESSION NOTES</Text>
            <TextInput
              style={styles.noteInput}
              placeholder="Overall observations, next steps..."
              placeholderTextColor={PALETTE.muted}
              value={sessionNote}
              onChangeText={setSessionNote}
              multiline
              numberOfLines={4}
            />
          </View>
        )}

        {/* Athlete edit permission */}
        {role === 'trainer' && (
          <View style={styles.permRow}>
            <View style={styles.permLeft}>
              <MaterialCommunityIcons name="account-edit-outline" size={18} color={PALETTE.silver} />
              <View>
                <Text style={styles.permLabel}>Allow athlete to edit</Text>
                <Text style={styles.permHint}>Athlete can update their own grades</Text>
              </View>
            </View>
            <Switch
              value={athleteCanEdit}
              onValueChange={setAthleteCanEditLocal}
              trackColor={{ false: PALETTE.panelAlt, true: PALETTE.accentSoft }}
              thumbColor={athleteCanEdit ? PALETTE.accent : PALETTE.silverDark}
            />
          </View>
        )}

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: PALETTE.background },

  header: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 16, paddingVertical: 14,
    borderBottomWidth: 1, borderBottomColor: PALETTE.divider, gap: 12,
  },
  backBtn: { padding: 4 },
  headerCenter: { flex: 1 },
  headerTitle: { color: PALETTE.text, fontSize: 18, fontWeight: '800' },
  headerSub: { color: PALETTE.muted, fontSize: 12, marginTop: 2 },
  saveBtn: {
    backgroundColor: PALETTE.accent, borderRadius: 10,
    paddingHorizontal: 16, paddingVertical: 8, minWidth: 60, alignItems: 'center',
  },
  saveBtnText: { color: '#fff', fontSize: 14, fontWeight: '800' },

  roleBanner: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    paddingHorizontal: 16, paddingVertical: 8,
    borderBottomWidth: 1,
  },
  roleBannerText: { fontSize: 12, fontWeight: '700' },

  scroll: { flex: 1 },
  scrollContent: { padding: 16, paddingBottom: 48 },

  partCard: {
    backgroundColor: PALETTE.panel, borderRadius: 16,
    borderWidth: 1, borderColor: PALETTE.border,
    marginBottom: 10, overflow: 'hidden',
  },
  partHeader: { flexDirection: 'row', alignItems: 'center', padding: 14, gap: 12 },
  partIconWrap: { width: 38, height: 38, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  partInfo: { flex: 1 },
  partName: { color: PALETTE.text, fontSize: 15, fontWeight: '800', marginBottom: 2 },
  partHint: { color: PALETTE.muted, fontSize: 11 },
  partRight: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  partGradeText: { fontSize: 18, fontWeight: '800' },
  templateBtn: {
    width: 36, height: 36, borderRadius: 10,
    backgroundColor: PALETTE.accentSoft,
    borderWidth: 1, borderColor: PALETTE.accent,
    alignItems: 'center', justifyContent: 'center',
  },
  recToggle: {
    flexDirection: 'row', alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: PALETTE.panelAlt, borderRadius: 10,
    borderWidth: 1, paddingHorizontal: 12, paddingVertical: 9,
    marginTop: 8,
  },
  recToggleLeft: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  recToggleLabel: { fontSize: 12, fontWeight: '700' },
  recList: {
    backgroundColor: PALETTE.panelAlt, borderRadius: 10,
    padding: 10, marginTop: 4, gap: 8,
  },
  recItem: { flexDirection: 'row', alignItems: 'flex-start', gap: 8 },
  recDot: { width: 6, height: 6, borderRadius: 3, marginTop: 5 },
  recText: { color: PALETTE.text, fontSize: 12, lineHeight: 18, flex: 1 },
  injuryBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 8,
    backgroundColor: PALETTE.panelAlt,
    borderWidth: 1,
    borderColor: PALETTE.border,
  },
  injuryBtnText: {
    color: PALETTE.muted,
    fontSize: 11,
    fontWeight: '700',
  },

  barTrack: {
    height: 4, backgroundColor: PALETTE.panelAlt,
    marginHorizontal: 14, marginBottom: 2, borderRadius: 999, overflow: 'visible',
  },
  barFill: { height: '100%', borderRadius: 999 },
  targetMarker: {
    position: 'absolute', top: -4, width: 2, height: 12,
    backgroundColor: PALETTE.accent, borderRadius: 1,
  },

  expanded: { padding: 14, paddingTop: 8, gap: 12 },

  inputRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  inputLabel: { color: PALETTE.silver, fontSize: 13, fontWeight: '700' },
  numInputWrap: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  numInput: {
    backgroundColor: PALETTE.panelAlt, borderRadius: 8,
    paddingHorizontal: 12, paddingVertical: 6,
    fontSize: 18, fontWeight: '800', minWidth: 56, textAlign: 'center',
    borderWidth: 1, borderColor: PALETTE.border,
  },
  pct: { fontSize: 16, fontWeight: '700' },

  readOnlyRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  readOnlyText: { color: PALETTE.accent, fontSize: 13, fontWeight: '700' },

  injuryBox: {
    backgroundColor: PALETTE.dangerSoft, borderRadius: 10,
    padding: 12, gap: 10,
    borderWidth: 1, borderColor: '#ef444433',
  },
  injuryBoxLabel: {
    color: PALETTE.danger, fontSize: 10, fontWeight: '800',
    textTransform: 'uppercase', letterSpacing: 1,
  },
  severityRow: { flexDirection: 'row', gap: 8 },
  sevBtn: {
    flex: 1, paddingVertical: 7, borderRadius: 8,
    backgroundColor: PALETTE.panelAlt, alignItems: 'center',
    borderWidth: 1, borderColor: PALETTE.border,
  },
  sevBtnActive: { backgroundColor: PALETTE.danger, borderColor: PALETTE.danger },
  sevBtnText: { color: PALETTE.muted, fontSize: 12, fontWeight: '700' },
  sevBtnTextActive: { color: '#fff' },
  injuryNoteInput: {
    backgroundColor: PALETTE.panel, borderRadius: 8,
    borderWidth: 1, borderColor: PALETTE.border,
    color: PALETTE.text, padding: 10, fontSize: 13,
    minHeight: 80, textAlignVertical: 'top',
  },
  injuryNoteReadOnly: { color: PALETTE.text, fontSize: 13, lineHeight: 19 },

  sectionLabel: {
    color: PALETTE.muted, fontSize: 10, fontWeight: '700',
    letterSpacing: 1.5, marginBottom: 8,
  },
  noteSection: { marginTop: 8, marginBottom: 16 },
  noteInput: {
    backgroundColor: PALETTE.panel, borderRadius: 14,
    borderWidth: 1, borderColor: PALETTE.border,
    color: PALETTE.text, padding: 14, fontSize: 14,
    minHeight: 110, textAlignVertical: 'top',
  },

  permRow: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: PALETTE.panel, borderRadius: 14,
    borderWidth: 1, borderColor: PALETTE.border,
    padding: 14, gap: 12,
  },
  permLeft: { flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1 },
  permLabel: { color: PALETTE.text, fontSize: 14, fontWeight: '700', marginBottom: 2 },
  permHint: { color: PALETTE.muted, fontSize: 11 },
});
