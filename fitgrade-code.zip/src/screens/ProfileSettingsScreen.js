import React, { useState } from 'react';
import {
  Alert,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { logOut, updateTrainerProfile } from '../services/firebaseService';
import PrivacyPolicyScreen from './PrivacyPolicyScreen';
import TermsOfServiceScreen from './TermsOfServiceScreen';
import { PALETTE } from '../ui/theme';

const SPECIALTIES = [
  'General Fitness',
  'Strength & Conditioning',
  'Sports Performance',
  'Rehabilitation',
  'Weight Loss',
  'Bodybuilding',
  'CrossFit',
  'Yoga & Mobility',
];

function SettingsRow({ icon, label, value, onPress, danger, rightElement }) {
  return (
    <TouchableOpacity
      style={[styles.settingsRow, danger && { borderColor: PALETTE.danger + '33' }]}
      onPress={onPress}
      activeOpacity={0.8}
    >
      <View style={[styles.settingsRowIcon, { backgroundColor: danger ? PALETTE.dangerSoft : PALETTE.panelAlt }]}>
        <MaterialCommunityIcons
          name={icon}
          size={18}
          color={danger ? PALETTE.danger : PALETTE.silver}
        />
      </View>
      <View style={styles.settingsRowInfo}>
        <Text style={[styles.settingsRowLabel, danger && { color: PALETTE.danger }]}>{label}</Text>
        {value ? <Text style={styles.settingsRowValue}>{value}</Text> : null}
      </View>
      {rightElement || (
        <MaterialCommunityIcons
          name="chevron-right"
          size={18}
          color={danger ? PALETTE.danger : PALETTE.muted}
        />
      )}
    </TouchableOpacity>
  );
}

function SectionHeader({ title }) {
  return <Text style={styles.sectionHeader}>{title}</Text>;
}

export default function ProfileSettingsScreen({ trainer, onBack, onSignOut }) {
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(trainer?.name || '');
  const [specialty, setSpecialty] = useState(trainer?.specialty || '');
  const [saving, setSaving] = useState(false);
  const [showSpecialties, setShowSpecialties] = useState(false);
  const [showPrivacy, setShowPrivacy] = useState(false);
  const [showTerms, setShowTerms] = useState(false);

  if (showPrivacy) return <PrivacyPolicyScreen onBack={() => setShowPrivacy(false)} />;
  if (showTerms) return <TermsOfServiceScreen onBack={() => setShowTerms(false)} />;

  const handleSave = async () => {
    if (!name.trim()) {
      Alert.alert('Error', 'Name cannot be empty.');
      return;
    }
    setSaving(true);
    const result = await updateTrainerProfile(trainer.uid, { name: name.trim(), specialty });
    setSaving(false);
    if (result.success) {
      setEditing(false);
      Alert.alert('Saved', 'Profile updated successfully.');
    } else {
      Alert.alert('Error', result.message || 'Could not save profile.');
    }
  };

  const handleSignOut = () => {
    Alert.alert('Sign Out', 'Are you sure you want to sign out?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Sign Out',
        style: 'destructive',
        onPress: async () => {
          await logOut();
          onSignOut?.();
        },
      },
    ]);
  };

  const handleDeleteAccount = () => {
    Alert.alert(
      'Delete Account',
      'This will permanently delete your account and all client data. This cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => Alert.alert('Coming Soon', 'Account deletion will be available in a future update.'),
        },
      ]
    );
  };

  return (
    <View style={styles.root}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack} style={styles.backBtn}>
          <MaterialCommunityIcons name="arrow-left" size={22} color={PALETTE.silver} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Profile & Settings</Text>
        {editing ? (
          <TouchableOpacity
            onPress={handleSave}
            style={[styles.saveBtn, saving && { opacity: 0.6 }]}
            disabled={saving}
          >
            <Text style={styles.saveBtnText}>{saving ? 'Saving...' : 'Save'}</Text>
          </TouchableOpacity>
        ) : (
          <TouchableOpacity onPress={() => setEditing(true)} style={styles.editBtn}>
            <MaterialCommunityIcons name="pencil-outline" size={18} color={PALETTE.accent} />
          </TouchableOpacity>
        )}
      </View>

      <ScrollView style={styles.scroll} contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>

        {/* Avatar */}
        <View style={styles.avatarSection}>
          <View style={styles.avatar}>
          <Text style={styles.avatarBgLetter}>{(name || 'T')[0].toUpperCase()}</Text>
          <Text style={styles.avatarText}>{(name || 'T')[0].toUpperCase()}</Text>
        </View>
          {editing && (
            <TouchableOpacity style={styles.changePhotoBtn}>
              <Text style={styles.changePhotoText}>Change photo</Text>
            </TouchableOpacity>
          )}
        </View>

        {/* Profile info */}
        <SectionHeader title="PROFILE" />
        <View style={styles.card}>
          <View style={styles.fieldRow}>
            <Text style={styles.fieldLabel}>Full name</Text>
            {editing ? (
              <TextInput
                style={styles.fieldInput}
                value={name}
                onChangeText={setName}
                autoCapitalize="words"
                placeholder="Your name"
                placeholderTextColor={PALETTE.muted}
              />
            ) : (
              <Text style={styles.fieldValue}>{name || '—'}</Text>
            )}
          </View>

          <View style={styles.fieldDivider} />

          <View style={styles.fieldRow}>
            <Text style={styles.fieldLabel}>Email</Text>
            <Text style={styles.fieldValue}>{trainer?.email || '—'}</Text>
          </View>

          <View style={styles.fieldDivider} />

          <View style={styles.fieldRow}>
            <Text style={styles.fieldLabel}>Specialty</Text>
            {editing ? (
              <TouchableOpacity
                onPress={() => setShowSpecialties(!showSpecialties)}
                style={styles.specialtyPicker}
              >
                <Text style={[styles.fieldValue, { color: PALETTE.accent }]}>
                  {specialty || 'Select specialty'}
                </Text>
                <MaterialCommunityIcons
                  name={showSpecialties ? 'chevron-up' : 'chevron-down'}
                  size={16}
                  color={PALETTE.accent}
                />
              </TouchableOpacity>
            ) : (
              <Text style={styles.fieldValue}>{specialty || '—'}</Text>
            )}
          </View>

          {/* Specialty dropdown */}
          {editing && showSpecialties && (
            <View style={styles.specialtyDropdown}>
              {SPECIALTIES.map((s) => (
                <TouchableOpacity
                  key={s}
                  onPress={() => { setSpecialty(s); setShowSpecialties(false); }}
                  style={[styles.specialtyOption, specialty === s && styles.specialtyOptionActive]}
                >
                  <Text style={[styles.specialtyOptionText, specialty === s && { color: PALETTE.accent }]}>
                    {s}
                  </Text>
                  {specialty === s && (
                    <MaterialCommunityIcons name="check" size={16} color={PALETTE.accent} />
                  )}
                </TouchableOpacity>
              ))}
            </View>
          )}
        </View>

        {/* Account */}
        <SectionHeader title="ACCOUNT" />
        <View style={styles.card}>
          <SettingsRow
            icon="lock-reset"
            label="Change password"
            onPress={() => Alert.alert('Coming Soon', 'Password change will be available in a future update.')}
          />
          <View style={styles.rowDivider} />
          <SettingsRow
            icon="bell-outline"
            label="Notifications"
            value="Coming soon"
            onPress={() => {}}
          />
          <View style={styles.rowDivider} />
          <SettingsRow
            icon="shield-outline"
            label="Privacy policy"
            onPress={() => setShowPrivacy(true)}
          />
          <View style={styles.rowDivider} />
          <SettingsRow
            icon="file-document-outline"
            label="Terms of service"
            onPress={() => setShowTerms(true)}
          />
          <View style={styles.rowDivider} />
          <SettingsRow
            icon="information-outline"
            label="App version"
            value="1.0.0"
            onPress={() => {}}
            rightElement={<View />}
          />
        </View>

        {/* Stats */}
        <SectionHeader title="YOUR STATS" />
        <View style={styles.statsRow}>
          <View style={styles.statCard}>
            <MaterialCommunityIcons name="account-group-outline" size={22} color={PALETTE.accent} />
            <Text style={styles.statNum}>{trainer?.clientCount ?? '—'}</Text>
            <Text style={styles.statLabel}>Clients</Text>
          </View>
          <View style={styles.statCard}>
            <MaterialCommunityIcons name="clipboard-check-outline" size={22} color={PALETTE.success} />
            <Text style={[styles.statNum, { color: PALETTE.success }]}>{trainer?.sessionCount ?? '—'}</Text>
            <Text style={styles.statLabel}>Sessions</Text>
          </View>
          <View style={styles.statCard}>
            <MaterialCommunityIcons name="calendar-outline" size={22} color={PALETTE.warning} />
            <Text style={[styles.statNum, { color: PALETTE.warning }]}>
              {trainer?.createdAt ? new Date(trainer.createdAt).toLocaleDateString('en-US', { month: 'short', year: 'numeric' }) : '—'}
            </Text>
            <Text style={styles.statLabel}>Member since</Text>
          </View>
        </View>

        {/* About FitGrade */}
        <SectionHeader title="ABOUT FITGRADE" />
        <View style={styles.aboutCard}>
          {/* Header */}
          <View style={styles.aboutHeader}>
            <MaterialCommunityIcons name="lightning-bolt" size={22} color={PALETTE.accent} />
            <View>
              <Text style={styles.aboutTitle}>FitGrade</Text>
              <Text style={styles.aboutVersion}>Version 1.0.0 · Beta</Text>
            </View>
          </View>

          <Text style={styles.aboutDesc}>
            Built for personal trainers and sports rehab professionals who want a simple, powerful way to track client health and performance — without the complexity of enterprise software.
          </Text>

          <View style={styles.aboutDivider} />

          {/* What's coming */}
          <Text style={styles.aboutRoadmapTitle}>What's coming in v2</Text>
          {[
            { icon: 'qrcode-scan', text: 'QR code org joining — athletes scan to join your roster' },
            { icon: 'lightning-bolt-outline', text: 'Training / Rehab / Performance modes per client' },
            { icon: 'bell-outline', text: 'Push notifications — session reminders for trainers' },
            { icon: 'file-export-outline', text: 'PDF export — share client progress reports' },
            { icon: 'account-multiple-outline', text: 'Org & gym accounts — manage multiple trainers' },
            { icon: 'chart-timeline-variant', text: 'Advanced analytics — roster trends over time' },
          ].map((item) => (
            <View key={item.text} style={styles.roadmapRow}>
              <MaterialCommunityIcons name={item.icon} size={15} color={PALETTE.accent} />
              <Text style={styles.roadmapText}>{item.text}</Text>
            </View>
          ))}

          <View style={styles.aboutDivider} />

          {/* Support / future paywall placeholder */}
          <TouchableOpacity
            style={styles.supportBtn}
            onPress={() => Alert.alert(
              'Support FitGrade',
              'Pro subscriptions are coming in v2. You\'ll be able to unlock unlimited clients, advanced analytics, and org management for $19.99/month.\n\nStay tuned!',
              [{ text: 'Got it' }]
            )}
            activeOpacity={0.85}
          >
            <MaterialCommunityIcons name="crown-outline" size={16} color="#fbbf24" />
            <Text style={styles.supportBtnText}>FitGrade Pro — Coming Soon</Text>
          </TouchableOpacity>
          <Text style={styles.supportHint}>Unlimited clients · Org accounts · Advanced AI · $19.99/mo</Text>
        </View>

        {/* Danger zone */}
        <SectionHeader title="DANGER ZONE" />
        <View style={styles.card}>
          <SettingsRow
            icon="logout"
            label="Sign out"
            danger
            onPress={handleSignOut}
          />
          <View style={styles.rowDivider} />
          <SettingsRow
            icon="delete-forever-outline"
            label="Delete account"
            danger
            onPress={handleDeleteAccount}
          />
        </View>

        <Text style={styles.footer}>FitGrade · Built for trainers</Text>

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: PALETTE.background },

  header: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 16, paddingVertical: 14,
    borderBottomWidth: 1, borderBottomColor: PALETTE.divider, gap: 12,
  },
  backBtn: { padding: 4 },
  headerTitle: { flex: 1, color: PALETTE.text, fontSize: 20, fontWeight: '800' },
  saveBtn: {
    backgroundColor: PALETTE.accent, borderRadius: 10,
    paddingHorizontal: 14, paddingVertical: 7,
  },
  saveBtnText: { color: '#fff', fontSize: 13, fontWeight: '800' },
  editBtn: { padding: 6 },

  scroll: { flex: 1 },
  scrollContent: { paddingBottom: 48 },

  avatarSection: { alignItems: 'center', paddingVertical: 28 },
  avatar: {
    width: 88, height: 88, borderRadius: 20,
    backgroundColor: PALETTE.panelAlt,
    borderWidth: 1.5, borderColor: PALETTE.border,
    alignItems: 'center', justifyContent: 'center',
    marginBottom: 10, overflow: 'hidden',
    position: 'relative',
  },
  avatarBgLetter: {
    position: 'absolute',
    fontSize: 72,
    fontWeight: '900',
    color: PALETTE.accent,
    opacity: 0.12,
  },
  avatarText: { color: PALETTE.accent, fontSize: 36, fontWeight: '800' },
  changePhotoBtn: { paddingVertical: 6, paddingHorizontal: 14 },
  changePhotoText: { color: PALETTE.accent, fontSize: 14, fontWeight: '700' },

  sectionHeader: {
    color: PALETTE.muted, fontSize: 10, fontWeight: '700',
    letterSpacing: 1.5, paddingHorizontal: 16,
    marginTop: 24, marginBottom: 8,
  },

  card: {
    backgroundColor: PALETTE.panel, borderRadius: 16,
    borderWidth: 1, borderColor: PALETTE.border,
    marginHorizontal: 16, overflow: 'hidden',
  },

  fieldRow: {
    flexDirection: 'row', alignItems: 'center',
    justifyContent: 'space-between', padding: 14, gap: 12,
  },
  fieldLabel: { color: PALETTE.silver, fontSize: 14, fontWeight: '700' },
  fieldValue: { color: PALETTE.text, fontSize: 14, fontWeight: '600', flex: 1, textAlign: 'right' },
  fieldInput: {
    flex: 1, color: PALETTE.text, fontSize: 14,
    textAlign: 'right', fontWeight: '600',
  },
  fieldDivider: { height: 1, backgroundColor: PALETTE.divider, marginHorizontal: 14 },

  specialtyPicker: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  specialtyDropdown: {
    borderTopWidth: 1, borderTopColor: PALETTE.divider,
    backgroundColor: PALETTE.panelAlt,
  },
  specialtyOption: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 12,
    borderBottomWidth: 1, borderBottomColor: PALETTE.divider,
  },
  specialtyOptionActive: { backgroundColor: PALETTE.accentSoft },
  specialtyOptionText: { color: PALETTE.text, fontSize: 14, fontWeight: '600' },

  settingsRow: {
    flexDirection: 'row', alignItems: 'center',
    padding: 14, gap: 12,
    borderWidth: 0,
  },
  settingsRowIcon: {
    width: 36, height: 36, borderRadius: 10,
    alignItems: 'center', justifyContent: 'center',
  },
  settingsRowInfo: { flex: 1 },
  settingsRowLabel: { color: PALETTE.text, fontSize: 14, fontWeight: '700' },
  settingsRowValue: { color: PALETTE.muted, fontSize: 12, marginTop: 2 },
  rowDivider: { height: 1, backgroundColor: PALETTE.divider, marginHorizontal: 14 },

  statsRow: {
    flexDirection: 'row', gap: 10,
    marginHorizontal: 16,
  },
  statCard: {
    flex: 1, backgroundColor: PALETTE.panel,
    borderRadius: 14, borderWidth: 1, borderColor: PALETTE.border,
    padding: 14, alignItems: 'center', gap: 6,
  },
  statNum: { color: PALETTE.text, fontSize: 18, fontWeight: '800' },
  statLabel: { color: PALETTE.muted, fontSize: 10, fontWeight: '700', textTransform: 'uppercase', textAlign: 'center' },

  footer: {
    color: PALETTE.muted, fontSize: 12,
    textAlign: 'center', marginTop: 32,
  },

  aboutCard: {
    backgroundColor: PALETTE.panel, borderRadius: 16,
    borderWidth: 1, borderColor: PALETTE.border,
    marginHorizontal: 16, padding: 16, gap: 12,
  },
  aboutHeader: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
  },
  aboutTitle: { color: PALETTE.text, fontSize: 16, fontWeight: '800' },
  aboutVersion: { color: PALETTE.muted, fontSize: 11, marginTop: 2 },
  aboutDesc: {
    color: PALETTE.muted, fontSize: 13, lineHeight: 20,
  },
  aboutDivider: {
    height: 1, backgroundColor: PALETTE.divider,
  },
  aboutRoadmapTitle: {
    color: PALETTE.text, fontSize: 13, fontWeight: '800', marginBottom: 4,
  },
  roadmapRow: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
  },
  roadmapText: {
    color: PALETTE.muted, fontSize: 12, lineHeight: 17, flex: 1,
  },
  supportBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: 8, backgroundColor: '#1a1500',
    borderRadius: 12, borderWidth: 1, borderColor: '#fbbf2444',
    paddingVertical: 12,
  },
  supportBtnText: { color: '#fbbf24', fontSize: 14, fontWeight: '800' },
  supportHint: {
    color: PALETTE.muted, fontSize: 11, textAlign: 'center',
  },
});
