import React from 'react';
import {
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { PALETTE } from '../ui/theme';

const SECTIONS = [
  {
    title: 'Information we collect',
    body: 'FitGrade collects the information you provide when creating an account (name, email address) and the health grade data you enter for your clients. We do not collect any sensitive personal health information beyond what you manually enter.',
  },
  {
    title: 'How we use your information',
    body: 'Your data is used solely to provide the FitGrade service — storing client health grades, session logs, and injury records so you can track progress over time. We do not sell, rent, or share your data with third parties.',
  },
  {
    title: 'Data storage',
    body: 'All data is stored securely using Google Firebase, which is protected by industry-standard encryption in transit and at rest. Your data is stored in the United States.',
  },
  {
    title: 'Data retention',
    body: 'Your data is retained as long as your account is active. You may delete your account and all associated data at any time from the Profile & Settings screen.',
  },
  {
    title: 'Third-party services',
    body: 'FitGrade uses Google Firebase for authentication and data storage. Firebase\'s privacy policy is available at firebase.google.com. No other third-party services have access to your data.',
  },
  {
    title: 'Children\'s privacy',
    body: 'FitGrade is intended for use by professional personal trainers and is not directed at children under 13. We do not knowingly collect personal information from children under 13.',
  },
  {
    title: 'Changes to this policy',
    body: 'We may update this privacy policy from time to time. We will notify you of any significant changes through the app. Continued use of FitGrade after changes constitutes acceptance of the updated policy.',
  },
  {
    title: 'Contact us',
    body: 'If you have questions about this privacy policy or how your data is handled, please contact us at privacy@fitgrade.app',
  },
];

export default function PrivacyPolicyScreen({ onBack }) {
  return (
    <View style={styles.root}>
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack} style={styles.backBtn}>
          <MaterialCommunityIcons name="arrow-left" size={22} color={PALETTE.silver} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Privacy Policy</Text>
        <View style={{ width: 30 }} />
      </View>

      <ScrollView style={styles.scroll} contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <Text style={styles.updated}>Last updated: May 2026</Text>
        <Text style={styles.intro}>
          FitGrade ("we", "us", "our") is committed to protecting your privacy. This policy explains what information we collect, how we use it, and your rights regarding your data.
        </Text>

        {SECTIONS.map((section) => (
          <View key={section.title} style={styles.section}>
            <Text style={styles.sectionTitle}>{section.title}</Text>
            <Text style={styles.sectionBody}>{section.body}</Text>
          </View>
        ))}

        <Text style={styles.footer}>FitGrade · Version 1.0.0</Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: PALETTE.background },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 14,
    borderBottomWidth: 1, borderBottomColor: PALETTE.divider,
  },
  backBtn: { padding: 4 },
  headerTitle: { color: PALETTE.text, fontSize: 18, fontWeight: '800' },
  scroll: { flex: 1 },
  scrollContent: { padding: 20, paddingBottom: 48 },
  updated: { color: PALETTE.muted, fontSize: 12, marginBottom: 14 },
  intro: {
    color: PALETTE.text, fontSize: 14, lineHeight: 22,
    backgroundColor: PALETTE.panel, borderRadius: 14,
    borderWidth: 1, borderColor: PALETTE.border,
    padding: 14, marginBottom: 20,
  },
  section: { marginBottom: 20 },
  sectionTitle: {
    color: PALETTE.accent, fontSize: 14, fontWeight: '800',
    marginBottom: 8, textTransform: 'capitalize',
  },
  sectionBody: { color: PALETTE.text, fontSize: 14, lineHeight: 22 },
  footer: {
    color: PALETTE.muted, fontSize: 12,
    textAlign: 'center', marginTop: 20,
  },
});
