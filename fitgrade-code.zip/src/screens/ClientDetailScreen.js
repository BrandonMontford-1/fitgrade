import React, { useEffect, useState } from 'react';
import {
  Modal,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import BodyHologram from '../components/BodyHologram';
import ProgressChart from '../components/ProgressChart';
import LogSessionScreen from './LogSessionScreen';
import SessionHistoryScreen from './SessionHistoryScreen';
import AITrainingPlanScreen from './AITrainingPlanScreen';
import {
  BODY_PARTS,
  PALETTE,
  PART_META,
  getAverageScore,
  getNumericGrade,
  getRecommendation,
  getSeverityMeta,
  gradeColor,
} from '../ui/theme';

const ROLES = ['trainer', 'athlete', 'coach'];
const ROLE_META = {
  trainer: { label: 'Trainer', icon: 'clipboard-edit-outline', color: PALETTE.accent },
  athlete: { label: 'Athlete', icon: 'account-outline', color: '#22c55e' },
  coach:   { label: 'Coach',   icon: 'eye-outline',           color: PALETTE.muted  },
};

const TABS = [
  { key: 'overview', icon: 'view-dashboard-outline', label: 'Overview' },
  { key: 'chart',    icon: 'chart-line',             label: 'Progress' },
  { key: 'history',  icon: 'clipboard-text-outline', label: 'History'  },
  { key: 'ai',       icon: 'lightning-bolt',          label: 'AI Plan'  },
];

export default function ClientDetailScreen({ client, trainerId, onBack }) {
  const [selectedPart, setSelectedPart] = useState('Core');
  const [role, setRole] = useState('trainer');
  const [activeTab, setActiveTab] = useState('overview');
  const [showLogSession, setShowLogSession] = useState(false);
  const [clientData, setClientData] = useState(client || {});
  const [refreshing, setRefreshing] = useState(false);
  const [pinnedNote, setPinnedNote] = useState(clientData?.pinnedNote || '');
  const [editingNote, setEditingNote] = useState(false);
  const [noteInput, setNoteInput] = useState(clientData?.pinnedNote || '');
  const [sessionCount, setSessionCount] = useState(0);

  useEffect(() => {
    const { loadSessions } = require('../services/firebaseService');
    loadSessions(trainerId, clientData.id).then((result) => {
      if (result.success) setSessionCount(result.data.length);
    });
  }, [clientData.id]);

  const handleRefresh = async () => {
    setRefreshing(true);
    // Re-fetch client data from Firebase
    const { loadClients } = require('../services/firebaseService');
    const result = await loadClients(trainerId);
    if (result.success && result.data[clientData.id]) {
      setClientData(result.data[clientData.id]);
    }
    setRefreshing(false);
  };

  const metrics = clientData;
  const avg = getAverageScore(metrics);
  const avgSeverity = getSeverityMeta(avg);
  const selGrade = getNumericGrade(metrics[selectedPart], 100);
  const selSeverity = getSeverityMeta(selGrade);
  const canEdit = role === 'trainer' || (role === 'athlete' && clientData?.athleteCanEdit);

  const handleSaved = (updatedData) => {
    setClientData((prev) => ({ ...prev, ...updatedData }));
  };

  if (showLogSession) {
    return (
      <LogSessionScreen
        client={clientData}
        trainerId={trainerId}
        role={role}
        onBack={() => setShowLogSession(false)}
        onSaved={handleSaved}
      />
    );
  }

  return (
    <View style={styles.root}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack} style={styles.backBtn}>
          <MaterialCommunityIcons name="arrow-left" size={22} color={PALETTE.silver} />
        </TouchableOpacity>
        <View style={styles.headerCenter}>
          <Text style={styles.headerName}>{clientData?.name || 'Client'}</Text>
          <Text style={styles.headerSub}>
            {clientData?.sport
              ? clientData.sport.charAt(0).toUpperCase() + clientData.sport.slice(1)
              : 'General'}
          </Text>
        </View>
        <View style={[styles.scoreBadge, { borderColor: avgSeverity.color }]}>
          <Text style={[styles.scoreNum, { color: avgSeverity.color }]}>{avg}</Text>
          <Text style={styles.scoreLabel}>AVG</Text>
        </View>
      </View>

      {/* Role toggle */}
      <View style={styles.roleRow}>
        {ROLES.map((r) => {
          const meta = ROLE_META[r];
          const active = role === r;
          return (
            <TouchableOpacity
              key={r}
              onPress={() => setRole(r)}
              style={[styles.roleBtn, active && { backgroundColor: meta.color + '22', borderColor: meta.color }]}
              activeOpacity={0.8}
            >
              <MaterialCommunityIcons name={meta.icon} size={13} color={active ? meta.color : PALETTE.muted} />
              <Text style={[styles.roleBtnText, active && { color: meta.color }]}>{meta.label}</Text>
            </TouchableOpacity>
          );
        })}
      </View>

      {/* Tab bar */}
      <View style={styles.tabBar}>
        {TABS.map((tab) => {
          const active = activeTab === tab.key;
          return (
            <TouchableOpacity
              key={tab.key}
              onPress={() => setActiveTab(tab.key)}
              style={[styles.tabBtn, active && styles.tabBtnActive]}
              activeOpacity={0.8}
            >
              <MaterialCommunityIcons
                name={tab.icon} size={16}
                color={active ? PALETTE.accent : PALETTE.muted}
              />
              <Text style={[styles.tabBtnText, active && styles.tabBtnTextActive]}>
                {tab.label}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>

      {/* ── OVERVIEW TAB ── */}
      {activeTab === 'overview' && (
        <ScrollView
          style={styles.scroll}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} tintColor={PALETTE.accent} />
          }
        >
          {/* Pinned note */}
          {(pinnedNote || role === 'trainer') && (
            <TouchableOpacity
              style={[styles.pinnedNote, !pinnedNote && styles.pinnedNotePlaceholder]}
              onPress={() => role === 'trainer' && setEditingNote(true)}
              activeOpacity={role === 'trainer' ? 0.8 : 1}
            >
              <MaterialCommunityIcons
                name="pin-outline"
                size={14}
                color={pinnedNote ? PALETTE.warning : PALETTE.muted}
              />
              {pinnedNote ? (
                <Text style={styles.pinnedNoteText}>{pinnedNote}</Text>
              ) : (
                <Text style={styles.pinnedNotePlaceholderText}>
                  Tap to pin a note about this client
                </Text>
              )}
              {role === 'trainer' && (
                <MaterialCommunityIcons name="pencil-outline" size={13} color={PALETTE.muted} />
              )}
            </TouchableOpacity>
          )}

          {/* Note editor modal */}
          <Modal visible={editingNote} transparent animationType="fade">
            <View style={styles.noteModalOverlay}>
              <View style={styles.noteModal}>
                <Text style={styles.noteModalTitle}>Pinned Note</Text>
                <TextInput
                  style={styles.noteModalInput}
                  value={noteInput}
                  onChangeText={setNoteInput}
                  placeholder="e.g. Peanut allergy, prefers morning sessions, ACL history..."
                  placeholderTextColor={PALETTE.muted}
                  multiline
                  numberOfLines={4}
                  autoFocus
                />
                <View style={styles.noteModalBtns}>
                  <TouchableOpacity
                    style={styles.noteModalCancel}
                    onPress={() => { setEditingNote(false); setNoteInput(pinnedNote); }}
                  >
                    <Text style={styles.noteModalCancelText}>Cancel</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={styles.noteModalSave}
                    onPress={() => { setPinnedNote(noteInput); setEditingNote(false); }}
                  >
                    <Text style={styles.noteModalSaveText}>Save</Text>
                  </TouchableOpacity>
                </View>
              </View>
            </View>
          </Modal>

          {/* Hologram + pills */}
          <View style={styles.bodySection}>
            <View style={styles.gradeCol}>
              {['Head', 'Arm', 'Core'].map((part) => {
                const g = getNumericGrade(metrics[part]);
                const color = gradeColor(g);
                const active = selectedPart === part;
                const injured = clientData?.injuries?.[part];
                return (
                  <TouchableOpacity key={part} onPress={() => setSelectedPart(part)}
                    style={[styles.gradePill, active && { borderColor: color, backgroundColor: color + '18' }, injured && { borderColor: PALETTE.danger }]}>
                    {injured && <MaterialCommunityIcons name="alert-circle" size={9} color={PALETTE.danger} style={styles.injuryDot} />}
                    <MaterialCommunityIcons name={PART_META[part].icon} size={13} color={active ? color : PALETTE.muted} />
                    <Text style={[styles.pillPart, { color: active ? color : PALETTE.muted }]}>{part}</Text>
                    <Text style={[styles.pillNum, { color }]}>{g}%</Text>
                    {clientData?.targets?.[part] > 0 && (
                      <Text style={styles.pillTarget}>→{clientData.targets[part]}%</Text>
                    )}
                  </TouchableOpacity>
                );
              })}
            </View>

            <View style={styles.hologramWrap}>
              <BodyHologram metrics={metrics} selectedPart={selectedPart} onRegionPress={setSelectedPart} />
            </View>

            <View style={styles.gradeCol}>
              {['Leg', 'Foot'].map((part) => {
                const g = getNumericGrade(metrics[part]);
                const color = gradeColor(g);
                const active = selectedPart === part;
                const injured = clientData?.injuries?.[part];
                return (
                  <TouchableOpacity key={part} onPress={() => setSelectedPart(part)}
                    style={[styles.gradePill, active && { borderColor: color, backgroundColor: color + '18' }, injured && { borderColor: PALETTE.danger }]}>
                    {injured && <MaterialCommunityIcons name="alert-circle" size={9} color={PALETTE.danger} style={styles.injuryDot} />}
                    <MaterialCommunityIcons name={PART_META[part].icon} size={13} color={active ? color : PALETTE.muted} />
                    <Text style={[styles.pillPart, { color: active ? color : PALETTE.muted }]}>{part}</Text>
                    <Text style={[styles.pillNum, { color }]}>{g}%</Text>
                    {clientData?.targets?.[part] > 0 && (
                      <Text style={styles.pillTarget}>→{clientData.targets[part]}%</Text>
                    )}
                  </TouchableOpacity>
                );
              })}
            </View>
          </View>

          {/* Session streak */}
          {sessionCount > 0 && (
            <View style={styles.streakBadge}>
              <MaterialCommunityIcons name="fire" size={14} color="#f97316" />
              <Text style={styles.streakText}>{sessionCount} session{sessionCount > 1 ? 's' : ''} logged</Text>
            </View>
          )}
          <View style={[styles.analysisCard, { borderColor: selSeverity.color + '44' }]}>
            <View style={styles.analysisRow}>
              <View style={[styles.analysisIcon, { backgroundColor: selSeverity.soft }]}>
                <MaterialCommunityIcons name={PART_META[selectedPart]?.icon ?? 'pulse'} size={20} color={selSeverity.color} />
              </View>
              <View style={styles.analysisCopy}>
                <Text style={[styles.analysisPartName, { color: selSeverity.color }]}>
                  {selectedPart} · {selGrade}%
                </Text>
                <Text style={styles.analysisRec}>{getRecommendation(selectedPart, selGrade)}</Text>
                {clientData?.injuries?.[selectedPart] && (
                  <Text style={styles.injuryWarning}>
                    ⚠ {clientData.injurySeverities?.[selectedPart] || 'Mild'} injury flagged
                    {clientData.injuryNotes?.[selectedPart] ? ` · ${clientData.injuryNotes[selectedPart]}` : ''}
                  </Text>
                )}
              </View>
              <View style={[styles.analysisBadge, { backgroundColor: selSeverity.soft }]}>
                <Text style={[styles.analysisBadgeText, { color: selSeverity.color }]}>{selSeverity.label}</Text>
              </View>
            </View>
          </View>

          {/* Log session / read only banners */}
          {canEdit ? (
            <TouchableOpacity style={styles.logBtn} onPress={() => setShowLogSession(true)} activeOpacity={0.85}>
              <MaterialCommunityIcons name="clipboard-plus-outline" size={20} color="#fff" />
              <Text style={styles.logBtnText}>
                {role === 'trainer' ? 'Log Session' : 'Update My Status'}
              </Text>
            </TouchableOpacity>
          ) : (
            <View style={styles.readOnlyBanner}>
              <MaterialCommunityIcons
                name={role === 'coach' ? 'eye-outline' : 'lock-outline'}
                size={15} color={PALETTE.muted}
              />
              <Text style={styles.readOnlyBannerText}>
                {role === 'coach' ? 'Coach view — read only' : 'Editing not enabled by trainer'}
              </Text>
            </View>
          )}

        </ScrollView>
      )}

      {/* ── PROGRESS TAB ── */}
      {activeTab === 'chart' && (
        <ScrollView style={styles.scroll} contentContainerStyle={{ paddingTop: 16, paddingBottom: 40 }} showsVerticalScrollIndicator={false}>
          <ProgressChart
            trainerId={trainerId}
            clientId={clientData.id}
            clientName={clientData.name}
          />
        </ScrollView>
      )}
      {/* ── HISTORY TAB ── */}
      {activeTab === 'history' && (
        <SessionHistoryScreen
          client={clientData}
          trainerId={trainerId}
          onBack={() => setActiveTab('overview')}
          hideHeader
        />
      )}
      {/* ── AI PLAN TAB ── */}
      {activeTab === 'ai' && (
        <AITrainingPlanScreen
          client={clientData}
          compDays={7}
          role={role}
          trainerId={trainerId}
          onBack={() => setActiveTab('overview')}
          hideHeader
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: PALETTE.background },

  header: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 16, paddingVertical: 14,
    borderBottomWidth: 1, borderBottomColor: PALETTE.divider, gap: 12,
  },
  backBtn: { padding: 4 },
  headerCenter: { flex: 1 },
  headerName: { color: PALETTE.text, fontSize: 20, fontWeight: '800' },
  headerSub: { color: PALETTE.muted, fontSize: 12, marginTop: 2 },
  scoreBadge: {
    width: 52, height: 52, borderRadius: 26,
    borderWidth: 1.5, alignItems: 'center', justifyContent: 'center',
    backgroundColor: PALETTE.panel,
  },
  scoreNum: { fontSize: 18, fontWeight: '800', lineHeight: 20 },
  scoreLabel: { color: PALETTE.muted, fontSize: 8, fontWeight: '700', letterSpacing: 1 },

  roleRow: {
    flexDirection: 'row', gap: 8,
    paddingHorizontal: 16, paddingVertical: 10,
    borderBottomWidth: 1, borderBottomColor: PALETTE.divider,
  },
  roleBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: 5, paddingVertical: 8, borderRadius: 10,
    borderWidth: 1, borderColor: PALETTE.border, backgroundColor: PALETTE.panel,
  },
  roleBtnText: { color: PALETTE.muted, fontSize: 11, fontWeight: '700' },

  tabBar: {
    flexDirection: 'row',
    paddingHorizontal: 16, paddingVertical: 8,
    borderBottomWidth: 1, borderBottomColor: PALETTE.divider, gap: 8,
  },
  tabBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: 6, paddingVertical: 8, borderRadius: 10,
    borderWidth: 1, borderColor: 'transparent',
  },
  tabBtnActive: {
    backgroundColor: PALETTE.accentSoft,
    borderColor: PALETTE.accent,
  },
  tabBtnText: { color: PALETTE.muted, fontSize: 12, fontWeight: '700' },
  tabBtnTextActive: { color: PALETTE.accent },

  pinnedNote: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    backgroundColor: '#1a1a0a', borderRadius: 12,
    borderWidth: 1, borderColor: PALETTE.warning + '44',
    paddingHorizontal: 12, paddingVertical: 10,
    marginBottom: 12,
  },
  pinnedNotePlaceholder: {
    borderColor: PALETTE.border,
    backgroundColor: PALETTE.panel,
  },
  pinnedNoteText: { flex: 1, color: PALETTE.text, fontSize: 13, lineHeight: 18 },
  pinnedNotePlaceholderText: { flex: 1, color: PALETTE.muted, fontSize: 13 },
  noteModalOverlay: {
    flex: 1, backgroundColor: 'rgba(0,0,0,0.7)',
    alignItems: 'center', justifyContent: 'center', padding: 24,
  },
  noteModal: {
    backgroundColor: PALETTE.panel, borderRadius: 16,
    borderWidth: 1, borderColor: PALETTE.border,
    padding: 18, width: '100%',
  },
  noteModalTitle: { color: PALETTE.text, fontSize: 16, fontWeight: '800', marginBottom: 12 },
  noteModalInput: {
    backgroundColor: PALETTE.panelAlt, borderRadius: 12,
    borderWidth: 1, borderColor: PALETTE.border,
    color: PALETTE.text, padding: 12, fontSize: 14,
    minHeight: 100, textAlignVertical: 'top', marginBottom: 14,
  },
  noteModalBtns: { flexDirection: 'row', gap: 10 },
  noteModalCancel: {
    flex: 1, backgroundColor: PALETTE.panelAlt,
    borderRadius: 10, borderWidth: 1, borderColor: PALETTE.border,
    paddingVertical: 10, alignItems: 'center',
  },
  noteModalCancelText: { color: PALETTE.muted, fontSize: 13, fontWeight: '700' },
  noteModalSave: {
    flex: 1, backgroundColor: PALETTE.accent,
    borderRadius: 10, paddingVertical: 10, alignItems: 'center',
  },
  noteModalSaveText: { color: '#fff', fontSize: 13, fontWeight: '800' },
  streakBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 5,
    backgroundColor: '#1a0f00', borderRadius: 8,
    borderWidth: 1, borderColor: '#f9731644',
    paddingHorizontal: 10, paddingVertical: 5,
    alignSelf: 'flex-start', marginBottom: 10,
  },
  streakText: { color: '#f97316', fontSize: 12, fontWeight: '700' },
  scrollContent: { paddingBottom: 40 },

  bodySection: {
    flexDirection: 'row', alignItems: 'center',
    justifyContent: 'space-between', paddingHorizontal: 8, paddingVertical: 16,
  },
  gradeCol: { flex: 1, gap: 8, alignItems: 'center' },
  gradePill: {
    width: '95%', backgroundColor: PALETTE.panel,
    borderRadius: 12, borderWidth: 1, borderColor: PALETTE.border,
    padding: 8, alignItems: 'center', gap: 3, position: 'relative',
  },
  injuryDot: { position: 'absolute', top: 4, right: 4 },
  pillPart: { fontSize: 9, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 0.5 },
  pillNum: { fontSize: 16, fontWeight: '800' },
  pillTarget: { color: PALETTE.accent, fontSize: 9, fontWeight: '700' },
  hologramWrap: { alignItems: 'center', justifyContent: 'center' },

  analysisCard: {
    marginHorizontal: 16, marginBottom: 12,
    backgroundColor: PALETTE.panel, borderRadius: 16,
    borderWidth: 1, padding: 14,
  },
  analysisRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 12 },
  analysisIcon: { width: 40, height: 40, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  analysisCopy: { flex: 1 },
  analysisPartName: { fontSize: 15, fontWeight: '800', marginBottom: 3 },
  analysisRec: { color: PALETTE.muted, fontSize: 12, lineHeight: 17, marginBottom: 4 },
  injuryWarning: { color: PALETTE.danger, fontSize: 11, fontWeight: '700' },
  analysisBadge: { borderRadius: 999, paddingHorizontal: 10, paddingVertical: 5 },
  analysisBadgeText: { fontSize: 11, fontWeight: '700' },

  logBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: 8, backgroundColor: PALETTE.accent, borderRadius: 14,
    marginHorizontal: 16, marginBottom: 16, paddingVertical: 14,
  },
  logBtnText: { color: '#fff', fontSize: 15, fontWeight: '800' },

  readOnlyBanner: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    marginHorizontal: 16, marginBottom: 16,
    backgroundColor: PALETTE.panel, borderRadius: 10,
    borderWidth: 1, borderColor: PALETTE.border,
    paddingHorizontal: 12, paddingVertical: 8,
  },
  readOnlyBannerText: { color: PALETTE.muted, fontSize: 12, fontWeight: '700' },

  sectionLabel: {
    color: PALETTE.muted, fontSize: 10, fontWeight: '700',
    letterSpacing: 1.5, paddingHorizontal: 16, marginBottom: 10,
  },
  gradeRow: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: PALETTE.panel, borderRadius: 14,
    borderWidth: 1, borderColor: PALETTE.border,
    marginHorizontal: 16, marginBottom: 8, padding: 12, gap: 12,
  },
  gradeRowIcon: { width: 38, height: 38, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  gradeRowInfo: { flex: 1 },
  gradeRowNameRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 2 },
  gradeRowPart: { color: PALETTE.text, fontSize: 15, fontWeight: '700' },
  injuredTag: { backgroundColor: PALETTE.dangerSoft, borderRadius: 4, paddingHorizontal: 6, paddingVertical: 2 },
  injuredTagText: { color: PALETTE.danger, fontSize: 9, fontWeight: '800', letterSpacing: 0.5 },
  gradeRowHint: { color: PALETTE.muted, fontSize: 11 },
  gradeRowTarget: { color: PALETTE.accent, fontSize: 11, fontWeight: '700', marginTop: 2 },
  gradeRowRight: { alignItems: 'flex-end', gap: 4 },
  gradeRowNum: { fontSize: 20, fontWeight: '800' },
  gradeRowBadge: { borderRadius: 999, paddingHorizontal: 8, paddingVertical: 3 },
  gradeRowBadgeText: { fontSize: 10, fontWeight: '700' },
});
