import React, { useEffect, useState, useCallback } from 'react';
import {
  ActivityIndicator,
  Alert,
  Modal,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  RefreshControl,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import PaywallScreen from './PaywallScreen';
import ProfileSettingsScreen from './ProfileSettingsScreen';
import EmptyState from '../components/EmptyState';
import InfoTooltip from '../components/InfoTooltip';
import WelcomeTip from '../components/WelcomeTip';
import { ClientCardSkeleton, SummarySkeleton } from '../components/SkeletonLoader';
import {
  addClient,
  deleteClient,
  loadClients,
  logOut,
  saveTrainerPrefs,
  loadTrainerPrefs,
} from '../services/firebaseService';
import {
  BODY_PARTS,
  PALETTE,
  getAverageScore,
  getNumericGrade,
  getPriorityArea,
  getSeverityMeta,
  gradeColor,
} from '../ui/theme';

const PART_COLORS = {
  Head: '#60a5fa',
  Arm:  '#a78bfa',
  Core: '#34d399',
  Leg:  '#fbbf24',
  Foot: '#f87171',
};

const INITIAL_CLIENT = {
  name: '',
  sport: '',
  age: '',
  Head: 100,
  Arm: 100,
  Core: 100,
  Leg: 100,
  Foot: 100,
};

// ─── Part icons map ───────────────────────────────────────────────────────────
const PART_ICONS = {
  Head: 'brain',
  Arm: 'arm-flex',
  Core: 'heart-pulse',
  Leg: 'run-fast',
  Foot: 'shoe-sneaker',
};

// ─── Letter grade avatar ──────────────────────────────────────────────────────
function LetterAvatar({ name, grade }) {
  const color = gradeColor(grade);
  const letter = (name || '?')[0].toUpperCase();
  const letterOpacity = 0.1 + (grade / 100) * 0.9;

  return (
    <View style={[styles.letterAvatarWrap, { borderColor: color }]}>
      {/* Ghost */}
      <Text style={styles.letterAvatarGhost}>{letter}</Text>
      {/* Filled letter */}
      <Text style={[styles.letterAvatarSolid, { color, opacity: letterOpacity }]}>
        {letter}
      </Text>
      {/* Grade underneath */}
      <Text style={[styles.letterAvatarGradeText, { color }]}>{grade}</Text>
    </View>
  );
}
function GradeCircle({ part, grade }) {
  const color = PART_COLORS[part];
  const borderWidth = 1.5 + (grade / 100) * 2;

  return (
    <View style={styles.gradeCircleWrap}>
      <View style={[styles.gradeCircle, { borderColor: color, borderWidth }]}>
        <Text style={[styles.gradeCircleInitial, { color }]}>{part[0]}</Text>
        <MaterialCommunityIcons name={PART_ICONS[part]} size={13} color={color} />
        <Text style={[styles.gradeCircleNum, { color }]}>{grade}</Text>
      </View>
    </View>
  );
}

// ─── Client Card ──────────────────────────────────────────────────────────────
function ClientCard({ client, onPress, onDelete }) {
  const avg = getAverageScore(client);
  const severity = getSeverityMeta(avg);
  const priority = getPriorityArea(client);

  return (
    <TouchableOpacity style={styles.clientCard} onPress={onPress} activeOpacity={0.85}>
      {/* Top row */}
      <View style={styles.clientCardTop}>
        <LetterAvatar name={client.name} grade={avg} />
        <View style={styles.clientInfo}>
          <Text style={styles.clientName}>{client.name}</Text>
          <Text style={styles.clientMeta}>
            {client.sport ? client.sport.charAt(0).toUpperCase() + client.sport.slice(1) : 'General'}{client.age ? `  ·  Age ${client.age}` : ''}
          </Text>
        </View>
        <View style={styles.clientScore}>
          <Text style={[styles.clientScoreNum, { color: severity.color }]}>{avg}</Text>
          <Text style={styles.clientScoreLabel}>SCORE</Text>
        </View>
      </View>

      {/* 5 grade circles */}
      <View style={styles.gradeCirclesRow}>
        {BODY_PARTS.map((part) => (
          <GradeCircle
            key={part}
            part={part}
            grade={getNumericGrade(client[part])}
          />
        ))}
      </View>

      {/* Bottom row */}
      <View style={styles.clientCardBottom}>
        <View style={[styles.priorityBadge, {
          backgroundColor: priority === 'None' ? PALETTE.successSoft : PALETTE.warningSoft,
        }]}>
          <Text style={[styles.priorityBadgeText, {
            color: priority === 'None' ? PALETTE.success : PALETTE.warning,
          }]}>
            {priority === 'None' ? '✓ Balanced' : `⚠ ${priority} Priority`}
          </Text>
        </View>
        <TouchableOpacity
          onPress={onDelete}
          style={styles.deleteBtn}
          hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
        >
          <MaterialCommunityIcons name="trash-can-outline" size={16} color={PALETTE.danger} />
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );
}

// ─── Add Client Modal ─────────────────────────────────────────────────────────
function AddClientModal({ visible, onClose, onAdd }) {
  const [form, setForm] = useState(INITIAL_CLIENT);
  const [loading, setLoading] = useState(false);

  const update = (field, value) => setForm((prev) => ({ ...prev, [field]: value }));

  const handleAdd = async () => {
    if (!form.name.trim()) { Alert.alert('Error', 'Please enter a client name.'); return; }
    setLoading(true);
    await onAdd({ ...form });
    setLoading(false);
    setForm(INITIAL_CLIENT);
    onClose();
  };

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <View style={styles.modalOverlay}>
        <View style={styles.modalCard}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>Add Client</Text>
            <TouchableOpacity onPress={onClose} style={styles.modalCloseBtn}>
              <MaterialCommunityIcons name="close" size={20} color={PALETTE.silver} />
            </TouchableOpacity>
          </View>

          <ScrollView showsVerticalScrollIndicator={false}>
            {/* Name */}
            <Text style={styles.label}>Full name *</Text>
            <TextInput style={styles.input} placeholder="John Smith" placeholderTextColor={PALETTE.muted}
              value={form.name} onChangeText={(v) => update('name', v)} autoCapitalize="words" />

            {/* Sport + Age */}
            <View style={styles.row}>
              <View style={{ flex: 1, marginRight: 8 }}>
                <Text style={styles.label}>Sport / Activity</Text>
                <TextInput style={styles.input} placeholder="Football" placeholderTextColor={PALETTE.muted}
                  value={form.sport} onChangeText={(v) => update('sport', v)} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.label}>Age</Text>
                <TextInput style={styles.input} placeholder="24" placeholderTextColor={PALETTE.muted}
                  value={form.age} onChangeText={(v) => update('age', v)} keyboardType="numeric" maxLength={3} />
              </View>
            </View>

            {/* Body grades */}
            <Text style={styles.label}>Initial grades (0–100)</Text>
            <View style={styles.gradesGrid}>
              {BODY_PARTS.map((part) => (
                <View key={part} style={styles.gradeInput}>
                  <Text style={styles.gradeInputLabel}>{part}</Text>
                  <TextInput
                    style={styles.gradeInputField}
                    value={String(form[part])}
                    onChangeText={(v) => update(part, v)}
                    keyboardType="numeric"
                    maxLength={3}
                    placeholderTextColor={PALETTE.muted}
                  />
                  <Text style={styles.gradeInputPct}>%</Text>
                </View>
              ))}
            </View>

            <TouchableOpacity style={[styles.primaryBtn, loading && { opacity: 0.7 }]}
              onPress={handleAdd} disabled={loading} activeOpacity={0.85}>
              {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.primaryBtnText}>Add Client</Text>}
            </TouchableOpacity>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

// ─── Trainer Home ─────────────────────────────────────────────────────────────
export default function TrainerHomeScreen({ trainer, onSelectClient }) {
  const [clients, setClients] = useState({});
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [addModalVisible, setAddModalVisible] = useState(false);
  const [paywallVisible, setPaywallVisible] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [search, setSearch] = useState('');
  const [filterMode, setFilterMode] = useState('all'); // all | injured | attention
  const [compDays, setCompDays] = useState(7);
  const [editingComp, setEditingComp] = useState(false);
  const [compDaysInput, setCompDaysInput] = useState('7');
  const [rosterNote, setRosterNote] = useState('');
  const [rosterNoteInput, setRosterNoteInput] = useState('');
  const [editingNotes, setEditingNotes] = useState(false);

  useEffect(() => {
    AsyncStorage.getItem('fitgrade_comp_days').then((val) => {
      if (val !== null) { setCompDays(parseInt(val)); setCompDaysInput(val); }
    });
    AsyncStorage.getItem('fitgrade_roster_note').then((val) => {
      if (val !== null) { setRosterNote(val); setRosterNoteInput(val); }
    });
    // Also load from Firebase as source of truth
    if (trainer?.uid) {
      loadTrainerPrefs(trainer.uid).then((result) => {
        if (result.success) {
          if (result.data.compDays) { setCompDays(result.data.compDays); setCompDaysInput(String(result.data.compDays)); }
          if (result.data.rosterNote) { setRosterNote(result.data.rosterNote); setRosterNoteInput(result.data.rosterNote); }
        }
      });
    }
  }, []);

  const saveCompDays = (val) => {
    const clamped = Math.max(0, Math.min(365, val));
    setCompDays(clamped);
    AsyncStorage.setItem('fitgrade_comp_days', String(clamped));
    if (trainer?.uid) saveTrainerPrefs(trainer.uid, { compDays: clamped, rosterNote });
  };

  const fetchClients = useCallback(async () => {
    const result = await loadClients(trainer.uid);
    if (result.success) setClients(result.data);
    setLoading(false);
    setRefreshing(false);
  }, [trainer.uid]);

  useEffect(() => { fetchClients(); }, [fetchClients]);

  const handleAddClient = async (clientData) => {
    const result = await addClient(trainer.uid, clientData);
    if (result.success) {
      setClients((prev) => ({
        ...prev,
        [result.id]: { id: result.id, ...clientData },
      }));
    } else {
      Alert.alert('Error', result.message);
    }
  };

  const handleDeleteClient = (clientId, clientName) => {
    Alert.alert('Remove Client', `Remove ${clientName} from your roster?`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Remove',
        style: 'destructive',
        onPress: async () => {
          const result = await deleteClient(trainer.uid, clientId);
          if (result.success) {
            setClients((prev) => {
              const next = { ...prev };
              delete next[clientId];
              return next;
            });
          }
        },
      },
    ]);
  };

  const handleLogout = async () => {
    Alert.alert('Sign Out', 'Are you sure you want to sign out?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Sign Out', style: 'destructive', onPress: logOut },
    ]);
  };

  const clientList = Object.values(clients).filter((c) => {
    const matchesSearch = c.name?.toLowerCase().includes(search.toLowerCase());
    if (!matchesSearch) return false;
    if (filterMode === 'injured') return Object.values(c.injuries || {}).some(Boolean);
    if (filterMode === 'attention') return getPriorityArea(c) !== 'None';
    return true;
  });

  const avgRoster = clientList.length
    ? Math.round(clientList.reduce((sum, c) => sum + getAverageScore(c), 0) / clientList.length)
    : 0;

  if (loading) {
    return (
      <View style={styles.loadingWrap}>
        <SummarySkeleton />
        <View style={styles.skeletonList}>
          <ClientCardSkeleton />
          <ClientCardSkeleton />
          <ClientCardSkeleton />
        </View>
      </View>
    );
  }

  return (
    <View style={styles.root}>
      <WelcomeTip />
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.headerEyebrow}>FitGrade</Text>
          <Text style={styles.headerTitle}>My Roster</Text>
        </View>
        <View style={styles.headerRight}>
          <TouchableOpacity onPress={() => setShowSettings(true)} style={styles.trainerBadge}>
            <Text style={styles.trainerBadgeText}>{(trainer.name || 'T')[0].toUpperCase()}</Text>
            <View style={styles.settingsHint}>
              <MaterialCommunityIcons name="cog" size={9} color={PALETTE.accentText} />
            </View>
          </TouchableOpacity>
        </View>
      </View>

      {/* Rich stats summary — only when clients exist */}
      {clientList.length > 0 && (
      <View style={styles.summarySection}>
        {/* Top row - main numbers */}
        <View style={styles.summaryTopRow}>
          {/* Roster health score */}
          <View style={[styles.summaryMain, { borderColor: PALETTE.accent + '44' }]}>
            <View style={styles.summaryLabelRow}>
              <Text style={styles.summaryEyebrow}>Roster Health</Text>
              <InfoTooltip text="The average health grade across all your clients. 90%+ is optimal, 70-89% needs monitoring, below 70% needs immediate attention." />
            </View>
            <Text style={[styles.summaryBigNum, { color: avgRoster >= 90 ? PALETTE.success : avgRoster >= 70 ? PALETTE.warning : PALETTE.danger }]}>
              {avgRoster}%
            </Text>
            <View style={styles.summaryTrendRow}>
              <MaterialCommunityIcons
                name={avgRoster >= 80 ? 'trending-up' : 'trending-down'}
                size={14}
                color={avgRoster >= 80 ? PALETTE.success : PALETTE.danger}
              />
              <Text style={[styles.summaryTrendText, { color: avgRoster >= 80 ? PALETTE.success : PALETTE.danger }]}>
                {avgRoster >= 90 ? 'Optimal' : avgRoster >= 70 ? 'Monitor' : 'Needs work'}
              </Text>
            </View>
          </View>

          {/* Right column mini stats */}
          <View style={styles.summaryMiniCol}>
            <View style={[styles.summaryMini, { borderColor: PALETTE.accent + '33' }]}>
              <MaterialCommunityIcons name="shield-outline" size={16} color={PALETTE.accent} />
              <View style={{ flex: 1 }}>
                <Text style={[styles.summaryMiniNum, { color: PALETTE.accent, fontSize: 13 }]} numberOfLines={1}>
                  {trainer?.specialty || trainer?.name || 'FitGrade'}
                </Text>
                <Text style={styles.summaryMiniLabel}>Group / Org</Text>
              </View>
            </View>
            <View style={styles.summaryMini}>
              <MaterialCommunityIcons name="account-group-outline" size={16} color={PALETTE.text} />
              <View>
                <Text style={styles.summaryMiniNum}>{clientList.length}</Text>
                <Text style={styles.summaryMiniLabel}>Total clients</Text>
              </View>
            </View>
            <View style={[styles.summaryMini, { borderColor: PALETTE.danger + '33' }]}>
              <MaterialCommunityIcons name="alert-circle-outline" size={16} color={PALETTE.danger} />
              <View>
                <Text style={[styles.summaryMiniNum, { color: PALETTE.danger }]}>
                  {clientList.filter((c) => Object.values(c.injuries || {}).some(Boolean)).length}
                </Text>
                <Text style={styles.summaryMiniLabel}>Active injuries</Text>
              </View>
            </View>
          </View>
        </View>

        {/* ── 3 insight cards ── */}
        {clientList.length > 0 && (
          <View style={styles.insightRow}>
            {/* Trainer Notes — big left card */}
            <TouchableOpacity
              style={[styles.insightCard, { flex: 1.2 }]}
              onPress={() => setEditingNotes(true)}
              activeOpacity={0.85}
            >
              <View style={styles.insightLabelRow}>
                <Text style={styles.insightLabel}>TRAINER NOTES</Text>
                <InfoTooltip text="Notes from the trainer visible to all athletes. Tap to edit." size={11} />
              </View>
              {rosterNote ? (
                <Text style={styles.insightNoteText} numberOfLines={4}>{rosterNote}</Text>
              ) : (
                <View style={styles.insightNotePlaceholder}>
                  <MaterialCommunityIcons name="pencil-plus-outline" size={20} color={PALETTE.muted} />
                  <Text style={styles.insightTipText}>Tap to add a note{'\n'}for your athletes</Text>
                </View>
              )}
            </TouchableOpacity>

            <View style={styles.insightColRight}>
              {/* Next comp */}
              <TouchableOpacity
                style={styles.insightCard}
                onPress={() => { setEditingComp(true); setCompDaysInput(String(compDays)); }}
                activeOpacity={0.8}
              >
                <View style={styles.insightLabelRow}>
                  <Text style={styles.insightLabel}>NEXT COMP</Text>
                  <InfoTooltip text="Days until next competition or event. Tap to update." size={11} />
                </View>
                <Text style={[styles.insightBigNum, {
                  color: compDays <= 3 ? PALETTE.danger : compDays <= 7 ? PALETTE.warning : PALETTE.accent,
                }]}>
                  {compDays}
                </Text>
                <Text style={styles.insightTipText}>days away</Text>
              </TouchableOpacity>

              {/* Active injuries */}
              <View style={[styles.insightCard, {
                borderColor: clientList.filter((c) => Object.values(c.injuries || {}).some(Boolean)).length > 0
                  ? PALETTE.danger + '44' : PALETTE.border
              }]}>
                <Text style={styles.insightLabel}>ACTIVE INJURIES</Text>
                <Text style={[styles.insightBigNum, {
                  color: clientList.filter((c) => Object.values(c.injuries || {}).some(Boolean)).length > 0
                    ? PALETTE.danger : PALETTE.success,
                  fontSize: 28,
                }]}>
                  {clientList.filter((c) => Object.values(c.injuries || {}).some(Boolean)).length}
                </Text>
                <Text style={styles.insightTipText}>
                  {clientList.filter((c) => Object.values(c.injuries || {}).some(Boolean)).length === 0
                    ? 'All clear' : 'clients injured'}
                </Text>
              </View>
            </View>
          </View>
        )}

        {/* Notes editor */}
        {editingNotes && (
          <View style={styles.compEditWrap}>
            <Text style={styles.insightLabel}>TRAINER NOTES FOR ATHLETES</Text>
            <TextInput
              style={[styles.compEditInput, { height: 100, textAlignVertical: 'top', fontSize: 14, padding: 12 }]}
              value={rosterNoteInput}
              onChangeText={setRosterNoteInput}
              placeholder="e.g. Great week everyone — focus on recovery this weekend..."
              placeholderTextColor={PALETTE.muted}
              multiline
              autoFocus
            />
            <View style={{ flexDirection: 'row', gap: 10, marginTop: 8 }}>
              <TouchableOpacity
                style={[styles.compEditSave, { flex: 1, backgroundColor: PALETTE.panel, borderWidth: 1, borderColor: PALETTE.border }]}
                onPress={() => setEditingNotes(false)}
              >
                <Text style={[styles.compEditSaveText, { color: PALETTE.muted }]}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.compEditSave, { flex: 1 }]}
                onPress={() => {
                  setRosterNote(rosterNoteInput);
                  AsyncStorage.setItem('fitgrade_roster_note', rosterNoteInput);
                  if (trainer?.uid) saveTrainerPrefs(trainer.uid, { compDays, rosterNote: rosterNoteInput });
                  setEditingNotes(false);
                }}
              >
                <Text style={styles.compEditSaveText}>Save</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/* Comp edit modal */}
        {editingComp && (
          <View style={styles.compEditWrap}>
            <Text style={styles.insightLabel}>DAYS UNTIL NEXT COMP</Text>
            <View style={styles.compEditRow}>
              <TextInput
                style={styles.compEditInput}
                value={compDaysInput}
                onChangeText={setCompDaysInput}
                keyboardType="numeric"
                maxLength={3}
                autoFocus
                selectTextOnFocus
              />
              <TouchableOpacity
                style={styles.compEditSave}
                onPress={() => {
                  const val = parseInt(compDaysInput) || 7;
                  saveCompDays(val);
                  setEditingComp(false);
                }}
              >
                <Text style={styles.compEditSaveText}>Save</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
      </View>
      )}

      {/* Search */}
      <View style={styles.searchWrap}>
        <MaterialCommunityIcons name="magnify" size={18} color={PALETTE.muted} style={{ marginRight: 8 }} />
        <TextInput
          style={styles.searchInput}
          placeholder="Search clients..."
          placeholderTextColor={PALETTE.muted}
          value={search}
          onChangeText={setSearch}
        />
      </View>

      {/* Filter pills */}
      <View style={styles.filterRow}>
        {[
          { key: 'all',       label: 'All' },
          { key: 'injured',   label: 'Injured' },
          { key: 'attention', label: 'Needs Attention' },
        ].map((f) => (
          <TouchableOpacity
            key={f.key}
            onPress={() => setFilterMode(f.key)}
            style={[styles.filterPill, filterMode === f.key && styles.filterPillActive]}
          >
            <Text style={[styles.filterPillText, filterMode === f.key && styles.filterPillTextActive]}>
              {f.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Client list */}
      <ScrollView
        style={styles.list}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={() => { setRefreshing(true); fetchClients(); }}
            tintColor={PALETTE.accent}
          />
        }
      >
        {clientList.length === 0 ? (
          <EmptyState
            icon="account-group-outline"
            title="No clients yet"
            subtitle="Add your first client to start tracking their health grades and progress."
            actionLabel="Add First Client"
            onAction={() => setAddModalVisible(true)}
          />
        ) : (
          clientList.map((client) => (
            <ClientCard
              key={client.id}
              client={client}
              onPress={() => onSelectClient(client)}
              onDelete={() => handleDeleteClient(client.id, client.name)}
            />
          ))
        )}
      </ScrollView>

      {/* Add client FAB */}
      <TouchableOpacity
        style={styles.fab}
        onPress={() => setAddModalVisible(true)}
        activeOpacity={0.85}
      >
        <MaterialCommunityIcons name="plus" size={28} color="#fff" />
      </TouchableOpacity>

      <AddClientModal
        visible={addModalVisible}
        onClose={() => setAddModalVisible(false)}
        onAdd={handleAddClient}
      />

      {showSettings && (
        <View style={StyleSheet.absoluteFill}>
          <ProfileSettingsScreen
            trainer={trainer}
            onBack={() => setShowSettings(false)}
            onSignOut={logOut}
          />
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: PALETTE.background },
  loadingWrap: { flex: 1, backgroundColor: PALETTE.background, paddingTop: 12 },
  skeletonList: { paddingHorizontal: 20, paddingTop: 12 },

  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end',
    paddingHorizontal: 20, paddingTop: 28, paddingBottom: 12,
  },
  headerEyebrow: { color: PALETTE.muted, fontSize: 11, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 1.2, marginBottom: 3 },
  headerTitle: { color: PALETTE.text, fontSize: 28, fontWeight: '800' },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  trainerBadge: {
    width: 38, height: 38, borderRadius: 19,
    backgroundColor: PALETTE.accentSoft, borderWidth: 1.5, borderColor: PALETTE.accent,
    alignItems: 'center', justifyContent: 'center',
    position: 'relative',
  },
  trainerBadgeText: { color: PALETTE.accent, fontSize: 16, fontWeight: '800' },
  settingsHint: {
    position: 'absolute',
    bottom: -2, right: -2,
    width: 14, height: 14, borderRadius: 7,
    backgroundColor: PALETTE.accent,
    alignItems: 'center', justifyContent: 'center',
  },
  logoutBtn: { padding: 6 },

  // Summary stats
  summaryLabelRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    marginBottom: 0,
  },
  insightLabelRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginBottom: 8,
  },
  summarySection: {
    marginHorizontal: 16,
    marginBottom: 14,
    gap: 10,
  },
  summaryTopRow: {
    flexDirection: 'row',
    gap: 10,
  },
  summaryMain: {
    flex: 1,
    backgroundColor: PALETTE.panel,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: PALETTE.border,
    padding: 14,
    justifyContent: 'center',
  },
  summaryEyebrow: {
    color: PALETTE.muted,
    fontSize: 10,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 1,
    marginBottom: 4,
  },
  summaryBigNum: {
    fontSize: 42,
    fontWeight: '800',
    lineHeight: 46,
    marginBottom: 4,
  },
  summaryTrendRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  summaryTrendText: {
    fontSize: 12,
    fontWeight: '700',
  },
  summaryMiniCol: {
    gap: 8,
    flex: 1,
  },
  summaryMini: {
    flex: 1,
    backgroundColor: PALETTE.panel,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: PALETTE.border,
    paddingHorizontal: 12,
    paddingVertical: 8,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  summaryMiniNum: {
    color: PALETTE.text,
    fontSize: 16,
    fontWeight: '800',
    lineHeight: 18,
  },
  summaryMiniLabel: {
    color: PALETTE.muted,
    fontSize: 10,
    fontWeight: '600',
  },
  // Insight cards
  insightRow: {
    flexDirection: 'row',
    gap: 10,
  },
  insightColRight: {
    flex: 1,
    gap: 10,
  },
  insightCard: {
    backgroundColor: PALETTE.panel,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: PALETTE.border,
    padding: 12,
    justifyContent: 'center',
  },
  insightNoteText: {
    color: PALETTE.text,
    fontSize: 13,
    lineHeight: 19,
    marginTop: 4,
  },
  insightNotePlaceholder: {
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 12,
  },
  insightLabel: {
    color: PALETTE.muted,
    fontSize: 9,
    fontWeight: '700',
    letterSpacing: 1.5,
    textTransform: 'uppercase',
  },
  insightLetterRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  insightLetterWrap: {
    width: 48,
    height: 52,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  insightLetterGhost: {
    position: 'absolute',
    fontSize: 44,
    fontWeight: '900',
    color: PALETTE.text,
    opacity: 0.06,
  },
  insightLetterSolid: {
    fontSize: 44,
    fontWeight: '900',
  },
  insightTipCopy: { flex: 1 },
  insightPartName: {
    fontSize: 12,
    fontWeight: '800',
    marginBottom: 4,
  },
  insightTipText: {
    color: PALETTE.muted,
    fontSize: 11,
    lineHeight: 16,
  },
  insightBigNum: {
    fontSize: 28,
    fontWeight: '800',
    lineHeight: 30,
    marginBottom: 2,
  },

  // Comp edit
  compEditWrap: {
    backgroundColor: PALETTE.panel,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#3b82f655',
    padding: 12,
    marginTop: 2,
  },
  compEditRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  compEditInput: {
    flex: 1,
    backgroundColor: PALETTE.panelAlt,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: PALETTE.border,
    color: PALETTE.text,
    fontSize: 20,
    fontWeight: '800',
    padding: 10,
    textAlign: 'center',
  },
  compEditSave: {
    backgroundColor: PALETTE.accent,
    borderRadius: 10,
    paddingHorizontal: 18,
    paddingVertical: 10,
  },
  compEditSaveText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '800',
  },

  searchWrap: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: PALETTE.panel, borderRadius: 14,
    borderWidth: 1, borderColor: PALETTE.border,
    paddingHorizontal: 14, marginHorizontal: 16, marginBottom: 8, height: 46,
  },
  searchInput: { flex: 1, color: PALETTE.text, fontSize: 14 },
  filterRow: {
    flexDirection: 'row', gap: 8,
    paddingHorizontal: 16, marginBottom: 10,
  },
  filterPill: {
    paddingHorizontal: 12, paddingVertical: 6,
    borderRadius: 999, backgroundColor: PALETTE.panel,
    borderWidth: 1, borderColor: PALETTE.border,
  },
  filterPillActive: {
    backgroundColor: PALETTE.accentSoft,
    borderColor: PALETTE.accent,
  },
  filterPillText: { color: PALETTE.muted, fontSize: 11, fontWeight: '700' },
  filterPillTextActive: { color: PALETTE.accent },

  list: { flex: 1 },
  listContent: { paddingHorizontal: 20, paddingBottom: 100 },

  clientCard: {
    backgroundColor: PALETTE.panel, borderRadius: 18,
    borderWidth: 1, borderColor: PALETTE.border,
    padding: 16, marginBottom: 12,
  },
  clientCardTop: { flexDirection: 'row', alignItems: 'center', marginBottom: 14 },
  // Letter avatar
  letterAvatarWrap: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: PALETTE.panelAlt,
    borderWidth: 2.5,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
    marginRight: 12,
  },
  letterAvatarGhost: {
    position: 'absolute',
    fontSize: 28,
    fontWeight: '900',
    color: PALETTE.text,
    opacity: 0.06,
    lineHeight: 32,
  },
  letterAvatarSolid: {
    fontSize: 28,
    fontWeight: '900',
    lineHeight: 32,
    marginBottom: 2,
  },
  letterAvatarGradeText: {
    fontSize: 9,
    fontWeight: '800',
    letterSpacing: 0.3,
    marginTop: -4,
  },
  clientInfo: { flex: 1 },
  clientName: { color: PALETTE.text, fontSize: 17, fontWeight: '800', marginBottom: 2 },
  clientMeta: { color: PALETTE.muted, fontSize: 12 },
  clientScore: { alignItems: 'flex-end' },
  clientScoreNum: { fontSize: 28, fontWeight: '800', lineHeight: 30 },
  clientScoreLabel: { color: PALETTE.muted, fontSize: 9, fontWeight: '700', letterSpacing: 1 },

  gradeCirclesRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 4,
    marginBottom: 14,
    marginTop: 4,
  },
  gradeCircleWrap: {
    alignItems: 'center',
  },
  gradeCircle: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: PALETTE.panelAlt,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 0,
  },
  gradeCircleInitial: {
    fontSize: 10,
    fontWeight: '900',
    opacity: 0.4,
    lineHeight: 12,
  },
  gradeCircleNum: {
    fontSize: 11,
    fontWeight: '800',
    lineHeight: 13,
  },

  clientCardBottom: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  priorityBadge: { borderRadius: 999, paddingHorizontal: 10, paddingVertical: 5 },
  priorityBadgeText: { fontSize: 11, fontWeight: '700' },
  deleteBtn: {
    width: 32, height: 32, borderRadius: 16,
    backgroundColor: PALETTE.dangerSoft, alignItems: 'center', justifyContent: 'center',
  },

  fab: {
    position: 'absolute', bottom: 48, right: 24,
    width: 58, height: 58, borderRadius: 29,
    backgroundColor: PALETTE.accent,
    alignItems: 'center', justifyContent: 'center',
    shadowColor: PALETTE.accent, shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4, shadowRadius: 12, elevation: 8,
  },

  // Modal
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.8)', justifyContent: 'flex-end' },
  modalCard: {
    backgroundColor: PALETTE.panel, borderTopLeftRadius: 24, borderTopRightRadius: 24,
    padding: 24, maxHeight: '90%',
    borderWidth: 1, borderColor: PALETTE.border,
  },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  modalTitle: { color: PALETTE.text, fontSize: 22, fontWeight: '800' },
  modalCloseBtn: {
    width: 34, height: 34, borderRadius: 17,
    backgroundColor: PALETTE.panelAlt, alignItems: 'center', justifyContent: 'center',
  },

  label: { color: PALETTE.silver, fontSize: 13, fontWeight: '700', marginBottom: 8, marginTop: 4 },
  input: {
    backgroundColor: PALETTE.input, color: PALETTE.text, borderRadius: 14,
    borderWidth: 1, borderColor: PALETTE.border,
    paddingHorizontal: 16, paddingVertical: 13, fontSize: 14, marginBottom: 12,
  },
  row: { flexDirection: 'row' },

  gradesGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 20 },
  gradeInput: {
    width: '30%', backgroundColor: PALETTE.panelAlt, borderRadius: 12,
    padding: 10, alignItems: 'center',
  },
  gradeInputLabel: { color: PALETTE.muted, fontSize: 11, fontWeight: '700', textTransform: 'uppercase', marginBottom: 6 },
  gradeInputField: { color: PALETTE.text, fontSize: 20, fontWeight: '800', textAlign: 'center', width: '100%' },
  gradeInputPct: { color: PALETTE.muted, fontSize: 12, marginTop: 2 },

  primaryBtn: {
    backgroundColor: PALETTE.accent, borderRadius: 14,
    height: 52, alignItems: 'center', justifyContent: 'center', marginTop: 4,
  },
  primaryBtnText: { color: '#fff', fontSize: 16, fontWeight: '800' },

  emptyState: { alignItems: 'center', paddingTop: 60 },
  emptyTitle: { color: PALETTE.text, fontSize: 20, fontWeight: '800', marginTop: 16, marginBottom: 8 },
  emptyText: { color: PALETTE.muted, fontSize: 14, textAlign: 'center' },
});
