import React, { useState } from 'react';
import {
  Alert,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { PALETTE } from '../ui/theme';

const FREE_FEATURES = [
  'Up to 3 clients',
  'Body grade tracking',
  'Session logging',
  'Injury flagging',
  'Basic progress view',
];

const PRO_FEATURES = [
  'Unlimited clients',
  'Full progress charts',
  'Target deadlines',
  'Session history',
  'Coach & athlete roles',
  'PDF export (coming soon)',
  'Priority support',
];

function FeatureRow({ text, included, highlight }) {
  return (
    <View style={styles.featureRow}>
      <MaterialCommunityIcons
        name={included ? 'check-circle' : 'close-circle-outline'}
        size={18}
        color={included ? (highlight ? '#fff' : PALETTE.success) : PALETTE.muted}
      />
      <Text style={[
        styles.featureText,
        !included && styles.featureTextMuted,
        highlight && styles.featureTextWhite,
      ]}>
        {text}
      </Text>
    </View>
  );
}

export default function PaywallScreen({ onClose, clientCount = 0 }) {
  const [selectedPlan, setSelectedPlan] = useState('yearly');
  const atLimit = clientCount >= 3;

  const handleUpgrade = () => {
    // Placeholder — wire RevenueCat or Stripe here
    Alert.alert(
      'Coming Soon',
      'Billing is being set up. Check back soon to upgrade to Pro!',
      [{ text: 'OK' }]
    );
  };

  return (
    <View style={styles.root}>
      {/* Header */}
      <View style={styles.header}>
        {onClose && (
          <TouchableOpacity onPress={onClose} style={styles.closeBtn}>
            <MaterialCommunityIcons name="close" size={22} color={PALETTE.silver} />
          </TouchableOpacity>
        )}
        <View style={styles.logoWrap}>
          <MaterialCommunityIcons name="lightning-bolt" size={28} color={PALETTE.accent} />
        </View>
        <Text style={styles.headerTitle}>Upgrade to Pro</Text>
        <Text style={styles.headerSub}>
          {atLimit
            ? "You've reached the 3 client limit on the free plan."
            : 'Unlock the full FitGrade experience.'}
        </Text>
      </View>

      <ScrollView style={styles.scroll} contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>

        {/* Billing toggle */}
        <View style={styles.billingToggle}>
          <TouchableOpacity
            onPress={() => setSelectedPlan('monthly')}
            style={[styles.billingBtn, selectedPlan === 'monthly' && styles.billingBtnActive]}
          >
            <Text style={[styles.billingBtnText, selectedPlan === 'monthly' && styles.billingBtnTextActive]}>
              Monthly
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => setSelectedPlan('yearly')}
            style={[styles.billingBtn, selectedPlan === 'yearly' && styles.billingBtnActive]}
          >
            <Text style={[styles.billingBtnText, selectedPlan === 'yearly' && styles.billingBtnTextActive]}>
              Yearly
            </Text>
            <View style={styles.saveBadge}>
              <Text style={styles.saveBadgeText}>Save 33%</Text>
            </View>
          </TouchableOpacity>
        </View>

        {/* Pro card */}
        <View style={styles.proCard}>
          <View style={styles.proCardHeader}>
            <View>
              <Text style={styles.proLabel}>PRO</Text>
              <View style={styles.priceRow}>
                <Text style={styles.priceNum}>
                  {selectedPlan === 'monthly' ? '$19.99' : '$13.33'}
                </Text>
                <Text style={styles.pricePer}>/mo</Text>
              </View>
              {selectedPlan === 'yearly' && (
                <Text style={styles.priceSub}>Billed $159.99/year</Text>
              )}
            </View>
            <View style={styles.proIconWrap}>
              <MaterialCommunityIcons name="crown" size={28} color="#fbbf24" />
            </View>
          </View>

          {PRO_FEATURES.map((f) => (
            <FeatureRow key={f} text={f} included highlight />
          ))}

          <TouchableOpacity style={styles.upgradeBtn} onPress={handleUpgrade} activeOpacity={0.85}>
            <MaterialCommunityIcons name="lightning-bolt" size={18} color="#000" />
            <Text style={styles.upgradeBtnText}>
              {selectedPlan === 'monthly' ? 'Start Pro — $19.99/mo' : 'Start Pro — $159.99/yr'}
            </Text>
          </TouchableOpacity>

          <Text style={styles.trialText}>7-day free trial · Cancel anytime</Text>
        </View>

        {/* Free card */}
        <View style={styles.freeCard}>
          <View style={styles.freeCardHeader}>
            <Text style={styles.freeLabel}>FREE</Text>
            <View style={styles.priceRow}>
              <Text style={styles.freePriceNum}>$0</Text>
              <Text style={[styles.pricePer, { color: PALETTE.muted }]}>/forever</Text>
            </View>
          </View>

          {FREE_FEATURES.map((f) => (
            <FeatureRow key={f} text={f} included={false} />
          ))}

          <View style={[styles.freeCurrentBadge]}>
            <Text style={styles.freeCurrentText}>✓ Your current plan</Text>
          </View>
        </View>

        {/* Footer */}
        <Text style={styles.footerText}>
          Payments securely processed. Subscriptions auto-renew unless cancelled at least 24 hours before the end of the current period.
        </Text>

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: PALETTE.background },

  header: {
    alignItems: 'center', paddingTop: 20, paddingBottom: 24,
    paddingHorizontal: 24, position: 'relative',
    borderBottomWidth: 1, borderBottomColor: PALETTE.divider,
  },
  closeBtn: {
    position: 'absolute', top: 20, right: 20,
    width: 34, height: 34, borderRadius: 17,
    backgroundColor: PALETTE.panel, alignItems: 'center', justifyContent: 'center',
  },
  logoWrap: {
    width: 56, height: 56, borderRadius: 28,
    backgroundColor: PALETTE.accentSoft, borderWidth: 1.5, borderColor: PALETTE.accent,
    alignItems: 'center', justifyContent: 'center', marginBottom: 12,
  },
  headerTitle: { color: PALETTE.text, fontSize: 26, fontWeight: '800', marginBottom: 6 },
  headerSub: { color: PALETTE.muted, fontSize: 14, textAlign: 'center', lineHeight: 20 },

  scroll: { flex: 1 },
  scrollContent: { padding: 20, paddingBottom: 48 },

  billingToggle: {
    flexDirection: 'row', backgroundColor: PALETTE.panel,
    borderRadius: 14, borderWidth: 1, borderColor: PALETTE.border,
    padding: 4, marginBottom: 16,
  },
  billingBtn: {
    flex: 1, paddingVertical: 10, borderRadius: 10,
    alignItems: 'center', flexDirection: 'row',
    justifyContent: 'center', gap: 6,
  },
  billingBtnActive: { backgroundColor: PALETTE.accent },
  billingBtnText: { color: PALETTE.muted, fontSize: 14, fontWeight: '700' },
  billingBtnTextActive: { color: '#fff' },
  saveBadge: {
    backgroundColor: '#fbbf2430', borderRadius: 6,
    paddingHorizontal: 6, paddingVertical: 2,
  },
  saveBadgeText: { color: '#fbbf24', fontSize: 10, fontWeight: '800' },

  // Pro card
  proCard: {
    backgroundColor: PALETTE.accent, borderRadius: 20,
    padding: 20, marginBottom: 12,
  },
  proCardHeader: {
    flexDirection: 'row', justifyContent: 'space-between',
    alignItems: 'flex-start', marginBottom: 16,
  },
  proLabel: {
    color: '#ffffff99', fontSize: 11, fontWeight: '800',
    letterSpacing: 1.5, marginBottom: 4,
  },
  priceRow: { flexDirection: 'row', alignItems: 'flex-end', gap: 4 },
  priceNum: { color: '#fff', fontSize: 36, fontWeight: '800', lineHeight: 40 },
  pricePer: { color: '#ffffff99', fontSize: 14, fontWeight: '600', marginBottom: 6 },
  priceSub: { color: '#ffffff88', fontSize: 12, marginTop: 2 },
  proIconWrap: {
    width: 52, height: 52, borderRadius: 26,
    backgroundColor: '#ffffff20',
    alignItems: 'center', justifyContent: 'center',
  },

  featureRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 10 },
  featureText: { color: PALETTE.text, fontSize: 14, fontWeight: '600', flex: 1 },
  featureTextMuted: { color: PALETTE.muted },
  featureTextWhite: { color: '#fff' },

  upgradeBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: 8, backgroundColor: '#fff', borderRadius: 14,
    paddingVertical: 14, marginTop: 16, marginBottom: 10,
  },
  upgradeBtnText: { color: '#000', fontSize: 15, fontWeight: '800' },
  trialText: { color: '#ffffff88', fontSize: 12, textAlign: 'center' },

  // Free card
  freeCard: {
    backgroundColor: PALETTE.panel, borderRadius: 20,
    borderWidth: 1, borderColor: PALETTE.border,
    padding: 20, marginBottom: 20,
  },
  freeCardHeader: { marginBottom: 16 },
  freeLabel: {
    color: PALETTE.muted, fontSize: 11, fontWeight: '800',
    letterSpacing: 1.5, marginBottom: 4,
  },
  freePriceNum: { color: PALETTE.text, fontSize: 36, fontWeight: '800', lineHeight: 40 },
  freeCurrentBadge: {
    backgroundColor: PALETTE.panelAlt, borderRadius: 10,
    paddingVertical: 10, alignItems: 'center', marginTop: 14,
    borderWidth: 1, borderColor: PALETTE.border,
  },
  freeCurrentText: { color: PALETTE.muted, fontSize: 13, fontWeight: '700' },

  footerText: {
    color: PALETTE.muted, fontSize: 11, textAlign: 'center',
    lineHeight: 16, paddingHorizontal: 10,
  },
});
