import { initializeApp, getApps, getApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { initializeAuth, getReactNativePersistence } from 'firebase/auth';
import ReactNativeAsyncStorage from '@react-native-async-storage/async-storage';

const firebaseConfig = {
  apiKey: "AIzaSyCXj3Cp0jJS88et9In3NhM3DtjfWd27L0c",
  authDomain: "fitgrade-96131.firebaseapp.com",
  projectId: "fitgrade-96131",
  storageBucket: "fitgrade-96131.firebasestorage.app",
  messagingSenderId: "368032620973",
  appId: "1:368032620973:web:cb9e08cc5bdb5bd606c124"
};

const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
const db = getFirestore(app);
const auth = initializeAuth(app, {
  persistence: getReactNativePersistence(ReactNativeAsyncStorage)
});

export { db, auth };
