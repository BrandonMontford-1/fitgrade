import { db, auth } from './firebaseConfig';
import {
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  addDoc,
  deleteDoc,
  updateDoc,
  query,
  orderBy,
} from 'firebase/firestore';
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
} from 'firebase/auth';

// ─── Auth ─────────────────────────────────────────────────────────────────────

export const signUp = async (email, password, name) => {
  try {
    const cred = await createUserWithEmailAndPassword(auth, email, password);
    await setDoc(doc(db, 'trainers', cred.user.uid), {
      name,
      email,
      role: 'trainer',
      createdAt: new Date().toISOString(),
    });
    return { success: true, user: cred.user };
  } catch (error) {
    return { success: false, message: error.message };
  }
};

export const logIn = async (email, password) => {
  try {
    const cred = await signInWithEmailAndPassword(auth, email, password);
    return { success: true, user: cred.user };
  } catch (error) {
    return { success: false, message: error.message };
  }
};

export const logOut = async () => {
  try {
    await signOut(auth);
    return { success: true };
  } catch (error) {
    return { success: false, message: error.message };
  }
};

export const onAuthChange = (callback) => onAuthStateChanged(auth, callback);

export const getTrainerProfile = async (uid) => {
  try {
    const snap = await getDoc(doc(db, 'trainers', uid));
    if (snap.exists()) return { success: true, data: snap.data() };
    return { success: false, message: 'Profile not found' };
  } catch (error) {
    return { success: false, message: error.message };
  }
};

export const updateTrainerProfile = async (uid, data) => {
  try {
    await updateDoc(doc(db, 'trainers', uid), {
      ...data,
      updatedAt: new Date().toISOString(),
    });
    return { success: true };
  } catch (error) {
    return { success: false, message: error.message };
  }
};

// ─── Clients ──────────────────────────────────────────────────────────────────

export const addClient = async (trainerId, clientData) => {
  try {
    const ref = await addDoc(collection(db, 'trainers', trainerId, 'clients'), {
      ...clientData,
      athleteCanEdit: false,
      targets: {},
      injuries: {},
      injuryNotes: {},
      injurySeverities: {},
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });
    return { success: true, id: ref.id };
  } catch (error) {
    return { success: false, message: error.message };
  }
};

export const loadClients = async (trainerId) => {
  try {
    const snap = await getDocs(collection(db, 'trainers', trainerId, 'clients'));
    const clients = {};
    snap.forEach((d) => { clients[d.id] = { id: d.id, ...d.data() }; });
    return { success: true, data: clients };
  } catch (error) {
    return { success: false, data: {}, message: error.message };
  }
};

export const updateClient = async (trainerId, clientId, data) => {
  try {
    await updateDoc(doc(db, 'trainers', trainerId, 'clients', clientId), {
      ...data,
      updatedAt: new Date().toISOString(),
    });
    return { success: true };
  } catch (error) {
    return { success: false, message: error.message };
  }
};

export const deleteClient = async (trainerId, clientId) => {
  try {
    await deleteDoc(doc(db, 'trainers', trainerId, 'clients', clientId));
    return { success: true };
  } catch (error) {
    return { success: false, message: error.message };
  }
};

// ─── Sessions ─────────────────────────────────────────────────────────────────

// Save a full session + update client's current grades/injuries/targets
export const saveSession = async (trainerId, clientId, sessionData) => {
  try {
    const {
      grades,
      targets,
      injuries,
      injuryNotes,
      injurySeverities,
      sessionNote,
    } = sessionData;

    const timestamp = new Date().toISOString();

    // 1. Log the session record
    const sessionRef = await addDoc(
      collection(db, 'trainers', trainerId, 'clients', clientId, 'sessions'),
      {
        grades,
        targets,
        injuries,
        injuryNotes,
        injurySeverities,
        sessionNote: sessionNote || '',
        timestamp,
      }
    );

    // 2. Update the client's current grades + metadata
    await updateDoc(doc(db, 'trainers', trainerId, 'clients', clientId), {
      ...grades,
      targets: targets || {},
      injuries: injuries || {},
      injuryNotes: injuryNotes || {},
      injurySeverities: injurySeverities || {},
      lastSessionAt: timestamp,
      updatedAt: timestamp,
    });

    return { success: true, sessionId: sessionRef.id };
  } catch (error) {
    console.error('saveSession error:', error);
    return { success: false, message: error.message };
  }
};

export const loadSessions = async (trainerId, clientId) => {
  try {
    const q = query(
      collection(db, 'trainers', trainerId, 'clients', clientId, 'sessions'),
      orderBy('timestamp', 'desc')
    );
    const snap = await getDocs(q);
    const sessions = [];
    snap.forEach((d) => sessions.push({ id: d.id, ...d.data() }));
    return { success: true, data: sessions };
  } catch (error) {
    return { success: false, data: [], message: error.message };
  }
};

export const deleteSession = async (trainerId, clientId, sessionId) => {
  try {
    await deleteDoc(
      doc(db, 'trainers', trainerId, 'clients', clientId, 'sessions', sessionId)
    );
    return { success: true };
  } catch (error) {
    return { success: false, message: error.message };
  }
};

// ─── Athlete edit permission ───────────────────────────────────────────────────

export const setAthleteCanEdit = async (trainerId, clientId, canEdit) => {
  try {
    await updateDoc(doc(db, 'trainers', trainerId, 'clients', clientId), {
      athleteCanEdit: canEdit,
      updatedAt: new Date().toISOString(),
    });
    return { success: true };
  } catch (error) {
    return { success: false, message: error.message };
  }
};

// ─── AI Plans ────────────────────────────────────────────────────────────────

export const saveTrainerPrefs = async (uid, prefs) => {
  try {
    await updateDoc(doc(db, 'trainers', uid), {
      prefs: prefs,
      updatedAt: new Date().toISOString(),
    });
    return { success: true };
  } catch (error) {
    return { success: false, message: error.message };
  }
};

export const loadTrainerPrefs = async (uid) => {
  try {
    const snap = await getDoc(doc(db, 'trainers', uid));
    if (snap.exists() && snap.data().prefs) {
      return { success: true, data: snap.data().prefs };
    }
    return { success: false };
  } catch (error) {
    return { success: false };
  }
};

export const saveAIPlan = async (trainerId, clientId, plan) => {
  try {
    await setDoc(
      doc(db, 'trainers', trainerId, 'clients', clientId, 'aiPlans', 'latest'),
      {
        ...plan,
        generatedAt: new Date().toISOString(),
      }
    );
    return { success: true };
  } catch (error) {
    return { success: false, message: error.message };
  }
};

export const loadAIPlan = async (trainerId, clientId) => {
  try {
    const snap = await getDoc(
      doc(db, 'trainers', trainerId, 'clients', clientId, 'aiPlans', 'latest')
    );
    if (snap.exists()) return { success: true, data: snap.data() };
    return { success: false, message: 'No plan found' };
  } catch (error) {
    return { success: false, message: error.message };
  }
};
