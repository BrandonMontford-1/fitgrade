export const PALETTE = {
  // Backgrounds
  background: '#08090f',
  surface: '#0f1018',
  panel: '#161820',
  panelAlt: '#1c1e2a',
  input: '#1a1c26',

  // Silver / text
  text: '#e8ecf4',
  muted: '#6b7890',
  silver: '#c0c8d8',
  silverLight: '#e8ecf4',
  silverDark: '#4a5268',

  // Blue accent
  accent: '#3b82f6',
  accentLight: '#60a5fa',
  accentDark: '#1d4ed8',
  accentText: '#ffffff',
  accentSoft: '#1e2d4a',

  // Status
  success: '#22c55e',
  successSoft: '#14291e',
  warning: '#f59e0b',
  warningSoft: '#2d2210',
  danger: '#ef4444',
  dangerSoft: '#2d1212',

  // Structure
  divider: '#1e2030',
  border: '#252838',
};

export const BODY_PARTS = ['Head', 'Arm', 'Core', 'Leg', 'Foot'];

export const PART_META = {
  Head: { icon: 'brain', label: 'Head', shortHint: 'Focus and cognitive readiness' },
  Arm: { icon: 'arm-flex', label: 'Arm', shortHint: 'Upper body power and stability' },
  Core: { icon: 'heart-pulse', label: 'Core', shortHint: 'Midline control and posture' },
  Leg: { icon: 'run-fast', label: 'Leg', shortHint: 'Drive, force, and sprint capacity' },
  Foot: { icon: 'shoe-sneaker', label: 'Foot', shortHint: 'Balance and push-off control' },
};

export const getNumericGrade = (grade, fallback = 100) => {
  const parsed = Number(grade);
  return Number.isFinite(parsed) ? parsed : fallback;
};

export const parseGradeValue = (value, fallback = null) => {
  const normalized = String(value ?? '').trim();
  if (normalized === '') return fallback;
  if (!/^\d{1,3}$/.test(normalized)) return fallback;
  const parsed = Number(normalized);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.max(0, Math.min(100, parsed));
};

export const getSeverityMeta = (grade) => {
  const g = getNumericGrade(grade);
  if (g >= 90) return { label: 'Optimal', color: PALETTE.success, soft: PALETTE.successSoft, text: '#a7f3c0' };
  if (g >= 70) return { label: 'Monitor', color: PALETTE.warning, soft: PALETTE.warningSoft, text: '#fde68a' };
  return { label: 'Priority', color: PALETTE.danger, soft: PALETTE.dangerSoft, text: '#fca5a5' };
};

export const getRecommendation = (part, grade) => {
  const g = getNumericGrade(grade);
  if (g >= 90) return `${part} is strong. Maintain current training load.`;
  if (g >= 70) return `${part} needs lighter load and additional recovery time.`;
  return `${part} requires immediate rehab focus before increasing intensity.`;
};

export const getPriorityArea = (metrics = {}) => {
  const lowest = BODY_PARTS.reduce((low, part) => {
    return getNumericGrade(metrics[part]) < getNumericGrade(metrics[low]) ? part : low;
  }, BODY_PARTS[0]);
  return getNumericGrade(metrics[lowest]) < 90 ? lowest : 'None';
};

export const getAverageScore = (metrics = {}) => {
  const total = BODY_PARTS.reduce((sum, part) => sum + getNumericGrade(metrics[part]), 0);
  return Math.round(total / BODY_PARTS.length);
};

export const formatDate = (timestamp) => {
  if (!timestamp) return 'Unknown date';
  const parsed = new Date(timestamp);
  if (isNaN(parsed.getTime())) return 'Unknown date';
  return parsed.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
};

export const gradeColor = (g) => {
  if (g >= 90) return PALETTE.success;
  if (g >= 70) return PALETTE.warning;
  return PALETTE.danger;
};
